-- phpMyAdmin SQL Dump
-- version 2.9.1.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Apr 28, 2008 at 10:14 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.0
-- 
-- Database: `exponent`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_addressbook_contact`
-- 

DROP TABLE IF EXISTS `exponent_addressbook_contact`;
CREATE TABLE IF NOT EXISTS `exponent_addressbook_contact` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `business` varchar(100) collate utf8_unicode_ci NOT NULL,
  `title` varchar(100) collate utf8_unicode_ci NOT NULL,
  `firstname` varchar(100) collate utf8_unicode_ci NOT NULL,
  `lastname` varchar(100) collate utf8_unicode_ci NOT NULL,
  `address1` varchar(150) collate utf8_unicode_ci NOT NULL,
  `address2` varchar(150) collate utf8_unicode_ci NOT NULL,
  `city` varchar(100) collate utf8_unicode_ci NOT NULL,
  `state` varchar(2) collate utf8_unicode_ci NOT NULL,
  `zip` varchar(10) collate utf8_unicode_ci NOT NULL,
  `country` varchar(50) collate utf8_unicode_ci NOT NULL,
  `email` varchar(150) collate utf8_unicode_ci NOT NULL,
  `email2` varchar(150) collate utf8_unicode_ci NOT NULL,
  `phone` varchar(20) collate utf8_unicode_ci NOT NULL,
  `cell` varchar(20) collate utf8_unicode_ci NOT NULL,
  `fax` varchar(20) collate utf8_unicode_ci NOT NULL,
  `pager` varchar(20) collate utf8_unicode_ci NOT NULL,
  `notes` text collate utf8_unicode_ci NOT NULL,
  `webpage` text collate utf8_unicode_ci NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_addressbook_contact`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_addressbookmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_addressbookmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_addressbookmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `sort_type` varchar(20) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_addressbookmodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_approvalpolicy`
-- 

DROP TABLE IF EXISTS `exponent_approvalpolicy`;
CREATE TABLE IF NOT EXISTS `exponent_approvalpolicy` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `max_approvers` int(8) NOT NULL,
  `required_approvals` int(8) NOT NULL,
  `on_deny` int(8) NOT NULL,
  `delete_on_deny` tinyint(1) NOT NULL,
  `on_edit` int(8) NOT NULL,
  `on_approve` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_approvalpolicy`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_approvalpolicyassociation`
-- 

DROP TABLE IF EXISTS `exponent_approvalpolicyassociation`;
CREATE TABLE IF NOT EXISTS `exponent_approvalpolicyassociation` (
  `policy_id` int(11) NOT NULL,
  `module` varchar(100) collate utf8_unicode_ci NOT NULL,
  `source` varchar(100) collate utf8_unicode_ci NOT NULL,
  `is_global` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_approvalpolicyassociation`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_article`
-- 

DROP TABLE IF EXISTS `exponent_article`;
CREATE TABLE IF NOT EXISTS `exponent_article` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `category_id` int(8) NOT NULL,
  `title` varchar(200) collate utf8_unicode_ci NOT NULL,
  `body` text collate utf8_unicode_ci NOT NULL,
  `rank` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_article`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_article_submission`
-- 

DROP TABLE IF EXISTS `exponent_article_submission`;
CREATE TABLE IF NOT EXISTS `exponent_article_submission` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `title` varchar(200) collate utf8_unicode_ci NOT NULL,
  `submitter_name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `submitter_email` varchar(200) collate utf8_unicode_ci NOT NULL,
  `file_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_article_submission`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_articlemodule_config`
-- 

DROP TABLE IF EXISTS `exponent_articlemodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_articlemodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `enable_categories` int(8) NOT NULL,
  `allow_submissions` int(8) NOT NULL,
  `require_login` int(8) NOT NULL,
  `recalc` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_articlemodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_banner_ad`
-- 

DROP TABLE IF EXISTS `exponent_banner_ad`;
CREATE TABLE IF NOT EXISTS `exponent_banner_ad` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `affiliate_id` int(11) NOT NULL,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  `file_id` int(11) NOT NULL,
  `url` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_banner_ad`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_banner_affiliate`
-- 

DROP TABLE IF EXISTS `exponent_banner_affiliate`;
CREATE TABLE IF NOT EXISTS `exponent_banner_affiliate` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `contact_info` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_banner_affiliate`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_banner_click`
-- 

DROP TABLE IF EXISTS `exponent_banner_click`;
CREATE TABLE IF NOT EXISTS `exponent_banner_click` (
  `id` int(11) NOT NULL auto_increment,
  `ad_id` int(11) NOT NULL,
  `clicks` int(8) NOT NULL,
  `views` int(8) NOT NULL,
  `date` int(14) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_banner_click`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_bb_board`
-- 

DROP TABLE IF EXISTS `exponent_bb_board`;
CREATE TABLE IF NOT EXISTS `exponent_bb_board` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  `num_topics` int(8) NOT NULL,
  `num_posts` int(8) NOT NULL,
  `is_locked` tinyint(1) NOT NULL,
  `last_post_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_bb_board`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_bb_boardmonitor`
-- 

DROP TABLE IF EXISTS `exponent_bb_boardmonitor`;
CREATE TABLE IF NOT EXISTS `exponent_bb_boardmonitor` (
  `board_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_bb_boardmonitor`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_bb_post`
-- 

DROP TABLE IF EXISTS `exponent_bb_post`;
CREATE TABLE IF NOT EXISTS `exponent_bb_post` (
  `id` int(11) NOT NULL auto_increment,
  `parent` int(11) NOT NULL,
  `board_id` int(11) NOT NULL,
  `subject` varchar(100) collate utf8_unicode_ci NOT NULL,
  `body` text collate utf8_unicode_ci NOT NULL,
  `quote` text collate utf8_unicode_ci NOT NULL,
  `poster` int(11) NOT NULL,
  `posted` int(14) NOT NULL,
  `updated` int(14) NOT NULL,
  `last_reply` int(11) NOT NULL,
  `editor` int(11) NOT NULL,
  `editted` int(14) NOT NULL,
  `is_sticky` tinyint(1) NOT NULL,
  `is_announcement` tinyint(1) NOT NULL,
  `is_locked` tinyint(1) NOT NULL,
  `num_views` int(8) NOT NULL,
  `num_replies` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_bb_post`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_bb_rank`
-- 

DROP TABLE IF EXISTS `exponent_bb_rank`;
CREATE TABLE IF NOT EXISTS `exponent_bb_rank` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `title` varchar(50) collate utf8_unicode_ci NOT NULL,
  `minimum_posts` int(8) NOT NULL,
  `is_special` tinyint(1) NOT NULL,
  `file_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_bb_rank`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_bb_ranks_users`
-- 

DROP TABLE IF EXISTS `exponent_bb_ranks_users`;
CREATE TABLE IF NOT EXISTS `exponent_bb_ranks_users` (
  `user_id` int(11) NOT NULL,
  `rank_id` int(11) NOT NULL,
  `is_special` int(8) NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`user_id`,`rank_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_bb_ranks_users`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_bb_threadmonitor`
-- 

DROP TABLE IF EXISTS `exponent_bb_threadmonitor`;
CREATE TABLE IF NOT EXISTS `exponent_bb_threadmonitor` (
  `thread_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_bb_threadmonitor`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_bb_user`
-- 

DROP TABLE IF EXISTS `exponent_bb_user`;
CREATE TABLE IF NOT EXISTS `exponent_bb_user` (
  `uid` int(11) NOT NULL,
  `icq_num` varchar(25) collate utf8_unicode_ci NOT NULL,
  `aim_addy` varchar(25) collate utf8_unicode_ci NOT NULL,
  `msn_addy` varchar(25) collate utf8_unicode_ci NOT NULL,
  `yahoo_addy` varchar(25) collate utf8_unicode_ci NOT NULL,
  `skype_addy` varchar(25) collate utf8_unicode_ci NOT NULL,
  `gtalk_addy` varchar(25) collate utf8_unicode_ci NOT NULL,
  `website` varchar(55) collate utf8_unicode_ci NOT NULL,
  `location` varchar(55) collate utf8_unicode_ci NOT NULL,
  `occupation` varchar(55) collate utf8_unicode_ci NOT NULL,
  `interests` text collate utf8_unicode_ci NOT NULL,
  `signature` text collate utf8_unicode_ci NOT NULL,
  `show_email_addy` tinyint(1) NOT NULL,
  `hide_online_status` tinyint(1) NOT NULL,
  `notify_of_replies` tinyint(1) NOT NULL,
  `notify_of_pvt_msg` tinyint(1) NOT NULL,
  `attach_signature` tinyint(1) NOT NULL,
  `num_posts` int(8) NOT NULL,
  `file_id` int(11) NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_bb_user`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_bb_user_board_visit`
-- 

DROP TABLE IF EXISTS `exponent_bb_user_board_visit`;
CREATE TABLE IF NOT EXISTS `exponent_bb_user_board_visit` (
  `board_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_visit` int(14) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_bb_user_board_visit`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_bbmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_bbmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_bbmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `email_title_thread` varchar(250) collate utf8_unicode_ci NOT NULL,
  `email_from_thread` varchar(100) collate utf8_unicode_ci NOT NULL,
  `email_address_thread` varchar(100) collate utf8_unicode_ci NOT NULL,
  `email_reply_thread` varchar(100) collate utf8_unicode_ci NOT NULL,
  `email_showpost_thread` tinyint(1) NOT NULL,
  `email_title_reply` varchar(250) collate utf8_unicode_ci NOT NULL,
  `email_from_reply` varchar(100) collate utf8_unicode_ci NOT NULL,
  `email_address_reply` varchar(100) collate utf8_unicode_ci NOT NULL,
  `email_reply_reply` varchar(100) collate utf8_unicode_ci NOT NULL,
  `email_showpost_reply` tinyint(1) NOT NULL,
  `email_signature` text collate utf8_unicode_ci NOT NULL,
  `whos_online` tinyint(1) NOT NULL,
  `items_perpage` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_bbmodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_calendar`
-- 

DROP TABLE IF EXISTS `exponent_calendar`;
CREATE TABLE IF NOT EXISTS `exponent_calendar` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `title` varchar(100) collate utf8_unicode_ci NOT NULL,
  `body` text collate utf8_unicode_ci NOT NULL,
  `eventstart` int(14) NOT NULL,
  `eventend` int(14) NOT NULL,
  `posted` int(14) NOT NULL,
  `poster` int(11) NOT NULL,
  `edited` int(14) NOT NULL,
  `editor` int(11) NOT NULL,
  `approved` tinyint(1) NOT NULL,
  `is_allday` tinyint(1) NOT NULL,
  `is_featured` tinyint(1) NOT NULL,
  `is_recurring` tinyint(1) NOT NULL,
  `category_id` int(11) NOT NULL,
  `feedback_form` varchar(100) collate utf8_unicode_ci NOT NULL,
  `feedback_email` text collate utf8_unicode_ci NOT NULL,
  `tags` text collate utf8_unicode_ci NOT NULL,
  `file_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Calendar post table.' AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `exponent_calendar`
-- 

INSERT IGNORE INTO `exponent_calendar` (`id`, `location_data`, `title`, `body`, `eventstart`, `eventend`, `posted`, `poster`, `edited`, `editor`, `approved`, `is_allday`, `is_featured`, `is_recurring`, `category_id`, `feedback_form`, `feedback_email`, `tags`, `file_id`) VALUES 
(1, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random4198072c7e088";s:3:"int";s:0:"";}', 'Example Calendar Event', 'This is an example calendar event.', 66600, 72000, 1100482605, 1, 1100482605, 1, 1, 0, 0, 0, 0, '', '', '', 0),
(2, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random4198072c7e088";s:3:"int";s:0:"";}', 'Another Event', 'Tum jugis reprobo delenit odio aliquam eu similis cogo te. Abigo validus paulatim utinam paulatim ea vel valde quod lucidus quibus. <br /><br />Ut foras commodo, exerci, multo nimis quis demoveo duis. Blandit exerci suscipit reprobo oppeto esca suscipit luptatum luptatum ut sit, delenit vel ut augue. Pagus incassum consequat multo nisl quod, abico autem rusticus metuo. Utinam nullus valetudo validus brevitas valetudo te epulae at dolus iriure, ea. Te ut ea abico qui loquor cui ibidem fatua genitus vicis in vereor abbas. Praemitto decet, sudo, feugiat in vel duis. Opto euismod quis facilisi dignissim pala, ventosus suscipit oppeto dolore mauris brevitas duis vel diam. <br /><br />Letalis, comis blandit oppeto sed commoveo causa, aliquip iusto feugiat paratus, ea ideo esse.', 25200, 31500, 1100482681, 1, 1100482681, 1, 1, 0, 0, 0, 0, '', '', '', 0),
(3, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random4198072c7e088";s:3:"int";s:0:"";}', '... Later That Day', 'This event shows that it is possible to have more than one event per day.', 52200, 54900, 1100482723, 1, 1100482723, 1, 1, 0, 0, 0, 0, '', '', '', 0),
(4, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}', 'Example Event', '<p>This is an example calendar event.</p>', 48900, 52500, 1170444982, 1, 0, 0, 1, 0, 0, 1, 0, '', '', 'a:0:{}', 0),
(5, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}', 'asdfasdf', '<p>asdfasdf</p>', 0, 0, 1204139096, 1, 0, 0, 1, 1, 0, 0, 0, '', '', 'a:0:{}', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_calendar_wf_info`
-- 

DROP TABLE IF EXISTS `exponent_calendar_wf_info`;
CREATE TABLE IF NOT EXISTS `exponent_calendar_wf_info` (
  `real_id` int(11) NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `current_major` int(8) NOT NULL,
  `current_minor` int(8) NOT NULL,
  `open_slots` int(8) NOT NULL,
  `updated` int(14) NOT NULL,
  `current_state_data` text collate utf8_unicode_ci NOT NULL,
  `policy_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Workflow Summary table for calendar';

-- 
-- Dumping data for table `exponent_calendar_wf_info`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_calendar_wf_revision`
-- 

DROP TABLE IF EXISTS `exponent_calendar_wf_revision`;
CREATE TABLE IF NOT EXISTS `exponent_calendar_wf_revision` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `title` varchar(100) collate utf8_unicode_ci NOT NULL,
  `body` text collate utf8_unicode_ci NOT NULL,
  `eventstart` int(14) NOT NULL,
  `eventend` int(14) NOT NULL,
  `posted` int(14) NOT NULL,
  `poster` int(11) NOT NULL,
  `edited` int(14) NOT NULL,
  `editor` int(11) NOT NULL,
  `approved` tinyint(1) NOT NULL,
  `is_allday` tinyint(1) NOT NULL,
  `is_featured` tinyint(1) NOT NULL,
  `is_recurring` tinyint(1) NOT NULL,
  `category_id` int(11) NOT NULL,
  `feedback_form` varchar(100) collate utf8_unicode_ci NOT NULL,
  `feedback_email` text collate utf8_unicode_ci NOT NULL,
  `tags` text collate utf8_unicode_ci NOT NULL,
  `file_id` int(11) NOT NULL,
  `wf_major` int(8) NOT NULL,
  `wf_minor` int(8) NOT NULL,
  `wf_original` int(11) NOT NULL,
  `wf_state_data` text collate utf8_unicode_ci NOT NULL,
  `wf_approved` tinyint(1) NOT NULL,
  `wf_type` int(8) NOT NULL,
  `wf_updated` int(14) NOT NULL,
  `wf_comment` text collate utf8_unicode_ci NOT NULL,
  `wf_user_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Workflow Revisions table for calendar' AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `exponent_calendar_wf_revision`
-- 

INSERT IGNORE INTO `exponent_calendar_wf_revision` (`id`, `location_data`, `title`, `body`, `eventstart`, `eventend`, `posted`, `poster`, `edited`, `editor`, `approved`, `is_allday`, `is_featured`, `is_recurring`, `category_id`, `feedback_form`, `feedback_email`, `tags`, `file_id`, `wf_major`, `wf_minor`, `wf_original`, `wf_state_data`, `wf_approved`, `wf_type`, `wf_updated`, `wf_comment`, `wf_user_id`) VALUES 
(1, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random4198072c7e088";s:3:"int";s:0:"";}', 'Example Calendar Event', 'This is an example calendar event.', 1101342600, 1101348000, 1100482605, 1, 0, 0, 0, 0, 0, 0, 0, '', '', '', 0, 1, 0, 1, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100482605, '', 0),
(2, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random4198072c7e088";s:3:"int";s:0:"";}', 'Another Event', 'Tum jugis reprobo delenit odio aliquam eu similis cogo te. Abigo validus paulatim utinam paulatim ea vel valde quod lucidus quibus. <br /><br />Ut foras commodo, exerci, multo nimis quis demoveo duis. Blandit exerci suscipit reprobo oppeto esca suscipit luptatum luptatum ut sit, delenit vel ut augue. Pagus incassum consequat multo nisl quod, abico autem rusticus metuo. Utinam nullus valetudo validus brevitas valetudo te epulae at dolus iriure, ea. Te ut ea abico qui loquor cui ibidem fatua genitus vicis in vereor abbas. Praemitto decet, sudo, feugiat in vel duis. Opto euismod quis facilisi dignissim pala, ventosus suscipit oppeto dolore mauris brevitas duis vel diam. <br /><br />Letalis, comis blandit oppeto sed commoveo causa, aliquip iusto feugiat paratus, ea ideo esse.', 1101819600, 1101825900, 1100482681, 1, 0, 0, 0, 0, 0, 0, 0, '', '', '', 0, 1, 0, 2, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100482681, '', 0),
(3, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random4198072c7e088";s:3:"int";s:0:"";}', '... Later That Day', 'This event shows that it is possible to have more than one event per day.', 1101846600, 1101849300, 1100482723, 1, 0, 0, 0, 0, 0, 0, 0, '', '', '', 0, 1, 0, 3, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100482723, '', 0),
(4, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}', 'Example Event', '<p>This is an example calendar event.</p>', 48900, 52500, 1170444982, 1, 0, 0, 2, 0, 0, 1, 0, '', '', 'a:0:{}', 0, 1, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1170444982, '', 1),
(5, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}', 'asdfasdf', '<p>asdfasdf</p>', 0, 0, 1204139096, 1, 0, 0, 2, 1, 0, 0, 0, '', '', 'a:0:{}', 0, 1, 0, 5, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1204139097, '', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_calendarmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_calendarmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_calendarmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `enable_categories` tinyint(1) NOT NULL,
  `enable_feedback` tinyint(1) NOT NULL,
  `enable_rss` tinyint(1) NOT NULL,
  `enable_tags` tinyint(1) NOT NULL,
  `collections` text collate utf8_unicode_ci NOT NULL,
  `group_by_tags` tinyint(1) NOT NULL,
  `show_tags` text collate utf8_unicode_ci NOT NULL,
  `feed_title` varchar(75) collate utf8_unicode_ci NOT NULL,
  `feed_desc` varchar(200) collate utf8_unicode_ci NOT NULL,
  `aggregate` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10)),
  KEY `collections` (`collections`(10)),
  KEY `show_tags` (`show_tags`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `exponent_calendarmodule_config`
-- 

INSERT IGNORE INTO `exponent_calendarmodule_config` (`id`, `location_data`, `enable_categories`, `enable_feedback`, `enable_rss`, `enable_tags`, `collections`, `group_by_tags`, `show_tags`, `feed_title`, `feed_desc`, `aggregate`) VALUES 
(1, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}', 0, 0, 1, 1, 'a:1:{i:0;s:1:"1";}', 0, 'a:0:{}', 'Example Exponent CMS Calendar', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_category`
-- 

DROP TABLE IF EXISTS `exponent_category`;
CREATE TABLE IF NOT EXISTS `exponent_category` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `color` varchar(7) collate utf8_unicode_ci NOT NULL,
  `rank` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_category`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_clipboard`
-- 

DROP TABLE IF EXISTS `exponent_clipboard`;
CREATE TABLE IF NOT EXISTS `exponent_clipboard` (
  `module` varchar(100) collate utf8_unicode_ci NOT NULL,
  `source` varchar(100) collate utf8_unicode_ci NOT NULL,
  `internal` varchar(100) collate utf8_unicode_ci NOT NULL,
  `title` varchar(100) collate utf8_unicode_ci NOT NULL,
  `view` varchar(100) collate utf8_unicode_ci NOT NULL,
  `copied_from` varchar(100) collate utf8_unicode_ci NOT NULL,
  `section_id` int(8) NOT NULL,
  `refcount` int(8) NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `operation` varchar(15) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`module`,`source`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_clipboard`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_contact_contact`
-- 

DROP TABLE IF EXISTS `exponent_contact_contact`;
CREATE TABLE IF NOT EXISTS `exponent_contact_contact` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `addressbook_contact_id` int(11) NOT NULL,
  `email` varchar(150) collate utf8_unicode_ci NOT NULL,
  `contact_info` text collate utf8_unicode_ci NOT NULL,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `exponent_contact_contact`
-- 

INSERT IGNORE INTO `exponent_contact_contact` (`id`, `user_id`, `addressbook_contact_id`, `email`, `contact_info`, `location_data`) VALUES 
(1, 1, 0, '', '', 'O:8:"stdClass":3:{s:3:"mod";s:13:"contactmodule";s:3:"src";s:20:"@random41940cfd10647";s:3:"int";s:0:"";}');

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_contactmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_contactmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_contactmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `subject` varchar(100) collate utf8_unicode_ci NOT NULL,
  `replyto_address` varchar(100) collate utf8_unicode_ci NOT NULL,
  `from_address` varchar(100) collate utf8_unicode_ci NOT NULL,
  `from_name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `final_message` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_contactmodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_container`
-- 

DROP TABLE IF EXISTS `exponent_container`;
CREATE TABLE IF NOT EXISTS `exponent_container` (
  `id` int(11) NOT NULL auto_increment,
  `internal` varchar(250) collate utf8_unicode_ci NOT NULL,
  `external` varchar(250) collate utf8_unicode_ci NOT NULL,
  `module` varchar(100) collate utf8_unicode_ci NOT NULL,
  `title` varchar(100) collate utf8_unicode_ci NOT NULL,
  `view` varchar(100) collate utf8_unicode_ci NOT NULL,
  `rank` int(8) NOT NULL,
  `is_existing` tinyint(1) NOT NULL,
  `view_data` text collate utf8_unicode_ci NOT NULL,
  `is_private` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=104 ;

-- 
-- Dumping data for table `exponent_container`
-- 

INSERT IGNORE INTO `exponent_container` (`id`, `internal`, `external`, `module`, `title`, `view`, `rank`, `is_existing`, `view_data`, `is_private`) VALUES 
(1, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:6:"@left1";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(2, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section1";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(3, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right1";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(4, 'O:8:"stdClass":3:{s:3:"mod";s:20:"administrationmodule";s:3:"src";N;s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right1";s:3:"int";s:0:"";}', '', '', 'Default', 3, 1, 'N;', 0),
(5, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419404caefcef";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right1";s:3:"int";s:0:"";}', '', 'About the Admin Mod', 'Default', 2, 0, 'N;', 0),
(6, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random4194052be45c3";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:6:"@left1";s:3:"int";s:0:"";}', '', 'Simple Text Mod', 'Default', 0, 0, 'N;', 0),
(8, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section1";s:3:"int";s:0:"";}', '', 'Welcome to Exponent CMS', 'Default', 1, 0, 'N;', 0),
(63, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:14:"@rightsidebar2";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(64, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:14:"@rightsidebar1";s:3:"int";s:0:"";}', '', 'My Website News', 'Summary', 0, 1, 'a:0:{}', 0),
(10, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419406fa74f12";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right1";s:3:"int";s:0:"";}', '', 'About News Feeds', 'Default', 0, 0, 'N;', 0),
(11, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:6:"@left2";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(12, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section2";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(13, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right2";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(15, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:6:"@left3";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(16, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section3";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(17, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right3";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(18, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random4194077998a8b";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section3";s:3:"int";s:0:"";}', '', 'About News Modules', 'Default', 0, 0, 'N;', 0),
(19, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:6:"@left4";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(20, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section4";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(21, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right4";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(22, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419407b5c3260";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right4";s:3:"int";s:0:"";}', '', '', 'Default', 0, 0, 'N;', 0),
(24, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:6:"@left7";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(25, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section7";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(26, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right7";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(27, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:6:"@left6";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(28, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section6";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(29, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right6";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(30, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random41940859f0402";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section6";s:3:"int";s:0:"";}', '', '', 'Default', 0, 0, 'N;', 0),
(31, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random4194088d88ad7";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section7";s:3:"int";s:0:"";}', '', 'Hidden Sections', 'Default', 0, 0, 'N;', 0),
(32, 'O:8:"stdClass":3:{s:3:"mod";s:20:"administrationmodule";s:3:"src";N;s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section7";s:3:"int";s:0:"";}', '', '', 'Default', 1, 1, 'N;', 0),
(33, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:6:"@left5";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(34, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section5";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(35, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right5";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(77, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section11";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(37, 'O:8:"stdClass":3:{s:3:"mod";s:12:"weblogmodule";s:3:"src";s:20:"@random41940a4020842";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section5";s:3:"int";s:0:"";}', '', 'Exponent Weblog', 'Summary', 0, 0, 'a:0:{}', 0),
(38, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section3";s:3:"int";s:0:"";}', '', 'My Website News', 'Default', 1, 0, 'a:0:{}', 0),
(39, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right1";s:3:"int";s:0:"";}', '', '', 'Summary', 1, 1, 'N;', 0),
(48, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:6:"@left9";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(49, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section9";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(41, 'O:8:"stdClass":3:{s:3:"mod";s:15:"resourcesmodule";s:3:"src";s:20:"@random41940ceb78dbb";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section6";s:3:"int";s:0:"";}', '', 'Exponent File Downloads', 'One Click Download - Descriptive', 1, 0, 'a:0:{}', 0),
(42, 'O:8:"stdClass":3:{s:3:"mod";s:13:"contactmodule";s:3:"src";s:20:"@random41940cfd10647";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section6";s:3:"int";s:0:"";}', '', 'Contact the Developers', 'Default', 3, 0, 'N;', 0),
(43, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random41940d1e14455";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section6";s:3:"int";s:0:"";}', '', 'Using Contact Forms', 'Default', 2, 0, 'N;', 0),
(44, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:6:"@left8";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(45, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section8";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(46, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right8";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(47, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random41940e2869238";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section8";s:3:"int";s:0:"";}', '', '', 'Default', 0, 0, 'N;', 0),
(50, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right9";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(51, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random4198038792cc4";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section9";s:3:"int";s:0:"";}', '', '', 'Default', 0, 0, 'N;', 0),
(62, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section4";s:3:"int";s:0:"";}', '', 'Example Calendar', 'Default', 0, 0, 'a:1:{s:10:"num_events";s:2:"15";}', 0),
(53, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random4198072c7e088";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@right4";s:3:"int";s:0:"";}', '', '', 'Mini-Calendar', 1, 1, 'N;', 0),
(54, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:5:"@left";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, 'N;', 0),
(55, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:14:"@rightsidebar7";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(56, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:14:"@rightsidebar3";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(57, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:14:"@rightsidebar6";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(58, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:14:"@rightsidebar5";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(59, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:14:"@rightsidebar4";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(61, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:14:"@rightsidebar1";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(65, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@footer";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(66, 'O:8:"stdClass":3:{s:3:"mod";s:20:"administrationmodule";s:3:"src";s:20:"@random4797672dc6ea6";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:5:"@left";s:3:"int";s:0:"";}', '', '', 'Quick Links', 0, 0, '', 0),
(67, 'O:8:"stdClass":3:{s:3:"mod";s:12:"searchmodule";s:3:"src";s:20:"@random47977a9d212f9";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:5:"@left";s:3:"int";s:0:"";}', '', '', 'Default', 1, 0, '', 0),
(80, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random47ae60f9710c1";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:5:"@left";s:3:"int";s:0:"";}', '', '', 'Default', 7, 0, '', 0),
(69, 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:5:"@left";s:3:"int";s:0:"";}', '', 'Related Links', 'Quicklinks', 4, 0, '', 0),
(92, 'O:8:"stdClass":3:{s:3:"mod";s:18:"imagegallerymodule";s:3:"src";s:20:"@random47b2476e0dd39";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section11";s:3:"int";s:0:"";}', '', '', 'All Galleries with Thumbnails', 0, 0, '', 0),
(71, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random479906c14489f";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:5:"@left";s:3:"int";s:0:"";}', '', '', 'Default', 6, 0, '', 0),
(72, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random479a38d73523f";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:7:"@footer";s:3:"int";s:0:"";}', '', '', 'Default', 0, 0, '', 0),
(76, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:5:"@left";s:3:"int";s:0:"";}', '', 'News', 'Summary', 3, 1, '', 0),
(81, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random47ae62abd87cb";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:5:"@left";s:3:"int";s:0:"";}', '', 'Donate to Exponent', 'Default', 5, 0, '', 0),
(82, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section12";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(83, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section13";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(84, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section10";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(85, 'O:8:"stdClass":3:{s:3:"mod";s:16:"navigationmodule";s:3:"src";s:20:"@random47ae7a369eab3";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section10";s:3:"int";s:0:"";}', '', 'Site Map', 'Site Map', 0, 0, '', 0),
(86, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section14";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(87, 'O:8:"stdClass":3:{s:3:"mod";s:12:"weblogmodule";s:3:"src";s:20:"@random41940a4020842";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:5:"@left";s:3:"int";s:0:"";}', '', 'Blogs by Month', 'Monthly', 2, 1, '', 0),
(88, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section15";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(95, 'O:8:"stdClass":3:{s:3:"mod";s:15:"resourcesmodule";s:3:"src";s:20:"@random41940ceb78dbb";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section12";s:3:"int";s:0:"";}', '', '', 'One Click Download - Descriptive', 1, 1, '', 0),
(94, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random41940859f0402";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section12";s:3:"int";s:0:"";}', '', 'About the Resource Module', 'Default', 0, 1, '', 0),
(96, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section16";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(98, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random41940d1e14455";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section16";s:3:"int";s:0:"";}', '', 'Using Contact Forms', 'Default', 0, 1, '', 0),
(99, 'O:8:"stdClass":3:{s:3:"mod";s:13:"contactmodule";s:3:"src";s:20:"@random41940cfd10647";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section16";s:3:"int";s:0:"";}', '', '', 'Default', 1, 1, '', 0),
(100, 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section17";s:3:"int";s:0:"";}', 'N;', '', '', 'Default', 0, 0, '', 0),
(101, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random47dacae9e1b86";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section17";s:3:"int";s:0:"";}', '', 'The Listing Module', 'Default', 0, 0, '', 0),
(102, 'O:8:"stdClass":3:{s:3:"mod";s:13:"listingmodule";s:3:"src";s:20:"@random47dacf258de2c";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:10:"@section17";s:3:"int";s:0:"";}', '', 'Some Random Listings', 'Default', 1, 0, 'a:1:{s:6:"perrow";s:0:"";}', 0),
(103, 'O:8:"stdClass":3:{s:3:"mod";s:18:"hotro_onlinemodule";s:3:"src";s:20:"@random4815dea590596";s:3:"int";s:0:"";}', 'O:8:"stdClass":3:{s:3:"mod";s:15:"containermodule";s:3:"src";s:9:"@section1";s:3:"int";s:0:"";}', '', 'test', 'Quicklinks', 0, 0, '', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_eventdate`
-- 

DROP TABLE IF EXISTS `exponent_eventdate`;
CREATE TABLE IF NOT EXISTS `exponent_eventdate` (
  `id` int(11) NOT NULL auto_increment,
  `event_id` int(11) NOT NULL,
  `date` int(14) NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=117 ;

-- 
-- Dumping data for table `exponent_eventdate`
-- 

INSERT IGNORE INTO `exponent_eventdate` (`id`, `event_id`, `date`, `location_data`) VALUES 
(1, 1, 1101276000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random4198072c7e088";s:3:"int";s:0:"";}'),
(2, 2, 1101794400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random4198072c7e088";s:3:"int";s:0:"";}'),
(3, 3, 1101794400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random4198072c7e088";s:3:"int";s:0:"";}'),
(4, 4, 1170828000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(5, 4, 1171432800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(6, 4, 1172037600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(7, 4, 1172642400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(8, 4, 1173247200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(9, 4, 1173848400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(10, 4, 1174453200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(11, 4, 1175058000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(12, 4, 1175662800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(13, 4, 1176267600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(14, 4, 1176872400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(15, 4, 1177477200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(16, 4, 1178082000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(17, 4, 1178686800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(18, 4, 1179291600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(19, 4, 1179896400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(20, 4, 1180501200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(21, 4, 1181106000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(22, 4, 1181710800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(23, 4, 1182315600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(24, 4, 1182920400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(25, 4, 1183525200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(26, 4, 1184130000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(27, 4, 1184734800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(28, 4, 1185339600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(29, 4, 1185944400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(30, 4, 1186549200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(31, 4, 1187154000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(32, 4, 1187758800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(33, 4, 1188363600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(34, 4, 1188968400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(35, 4, 1189573200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(36, 4, 1190178000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(37, 4, 1190782800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(38, 4, 1191387600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(39, 4, 1191992400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(40, 4, 1192597200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(41, 4, 1193202000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(42, 4, 1193806800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(43, 4, 1194415200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(44, 4, 1195020000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(45, 4, 1195624800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(46, 4, 1196229600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(47, 4, 1196834400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(48, 4, 1197439200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(49, 4, 1198044000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(50, 4, 1198648800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(51, 4, 1199253600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(52, 4, 1199858400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(53, 4, 1200463200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(54, 4, 1201068000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(55, 4, 1201672800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(56, 4, 1202277600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(57, 4, 1202882400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(58, 4, 1203487200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(59, 4, 1204092000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(60, 4, 1204696800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(61, 4, 1205298000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(62, 4, 1205902800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(63, 4, 1206507600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(64, 4, 1207112400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(65, 4, 1207717200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(66, 4, 1208322000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(67, 4, 1208926800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(68, 4, 1209531600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(69, 4, 1210136400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(70, 4, 1210741200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(71, 4, 1211346000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(72, 4, 1211950800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(73, 4, 1212555600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(74, 4, 1213160400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(75, 4, 1213765200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(76, 4, 1214370000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(77, 4, 1214974800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(78, 4, 1215579600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(79, 4, 1216184400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(80, 4, 1216789200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(81, 4, 1217394000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(82, 4, 1217998800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(83, 4, 1218603600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(84, 4, 1219208400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(85, 4, 1219813200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(86, 4, 1220418000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(87, 4, 1221022800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(88, 4, 1221627600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(89, 4, 1222232400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(90, 4, 1222837200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(91, 4, 1223442000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(92, 4, 1224046800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(93, 4, 1224651600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(94, 4, 1225256400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(95, 4, 1225864800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(96, 4, 1226469600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(97, 4, 1227074400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(98, 4, 1227679200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(99, 4, 1228284000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(100, 4, 1228888800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(101, 4, 1229493600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(102, 4, 1230098400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(103, 4, 1230703200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(104, 4, 1231308000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(105, 4, 1231912800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(106, 4, 1232517600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(107, 4, 1233122400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(108, 4, 1233727200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(109, 4, 1234332000, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(110, 4, 1234936800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(111, 4, 1235541600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(112, 4, 1236146400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(113, 4, 1236747600, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(114, 4, 1237352400, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(115, 4, 1237957200, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}'),
(116, 5, 1204264800, 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}');

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_faq`
-- 

DROP TABLE IF EXISTS `exponent_faq`;
CREATE TABLE IF NOT EXISTS `exponent_faq` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `category_id` int(8) NOT NULL,
  `question` varchar(200) collate utf8_unicode_ci NOT NULL,
  `answer` text collate utf8_unicode_ci NOT NULL,
  `rank` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_faq`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_faqmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_faqmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_faqmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `enable_categories` int(8) NOT NULL,
  `recalc` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_faqmodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_file`
-- 

DROP TABLE IF EXISTS `exponent_file`;
CREATE TABLE IF NOT EXISTS `exponent_file` (
  `id` int(11) NOT NULL auto_increment,
  `directory` varchar(250) collate utf8_unicode_ci NOT NULL,
  `filename` varchar(250) collate utf8_unicode_ci NOT NULL,
  `name` varchar(250) collate utf8_unicode_ci NOT NULL,
  `collection_id` int(11) NOT NULL,
  `mimetype` varchar(100) collate utf8_unicode_ci NOT NULL,
  `poster` int(11) NOT NULL,
  `posted` int(14) NOT NULL,
  `filesize` int(8) NOT NULL,
  `accesscount` int(8) NOT NULL,
  `last_accessed` int(14) NOT NULL,
  `image_width` int(8) NOT NULL,
  `image_height` int(8) NOT NULL,
  `is_image` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=37 ;

-- 
-- Dumping data for table `exponent_file`
-- 

INSERT IGNORE INTO `exponent_file` (`id`, `directory`, `filename`, `name`, `collection_id`, `mimetype`, `poster`, `posted`, `filesize`, `accesscount`, `last_accessed`, `image_width`, `image_height`, `is_image`) VALUES 
(8, 'files/resourcesmodule/@random41940ceb78dbb', '1100483107_example.sxw', '', 0, 'application/vnd.sun.xml.writer', 1, 1100483107, 5237, 0, 1100483107, 0, 0, 0),
(7, 'files/resourcesmodule/@random41940ceb78dbb', '1100483043_example.pdf', '', 0, 'application/pdf', 1, 1100483043, 9535, 0, 1100483043, 0, 0, 0),
(31, 'files/imagegallerymodule/@random47b2476e0dd39/gallery15', 'DSC00521.JPG', '', 0, 'image/jpeg', 1, 1202870589, 161650, 0, 1202870589, 640, 480, 1),
(19, 'files', 'freddphooey.jpg', '', 0, 'image/pjpeg', 1, 1202624546, 2057, 0, 1202624546, 71, 80, 1),
(20, 'files', 'expbox.jpg', '', 0, 'image/jpeg', 1, 1202628644, 40462, 0, 1202628644, 250, 253, 1),
(30, 'files/imagegallerymodule/@random47b2476e0dd39/gallery15', 'DSC00520.JPG', '', 0, 'image/jpeg', 1, 1202870549, 149189, 0, 1202870549, 640, 480, 1),
(29, 'files/imagegallerymodule/@random47b2476e0dd39/gallery15', 'DSC00519.JPG', '', 0, 'image/jpeg', 1, 1202870548, 146196, 0, 1202870548, 640, 480, 1),
(25, 'files/imagegallerymodule/@random47a287864cd25/gallery14', 'Photo_8.jpg', '', 0, 'image/jpeg', 1, 1202634273, 61541, 0, 1202634273, 640, 480, 1),
(28, 'files/imagegallerymodule/@random47b2476e0dd39/gallery15', 'DSC00518.JPG', '', 0, 'image/jpeg', 1, 1202870547, 144358, 0, 1202870547, 640, 480, 1),
(32, 'files/imagegallerymodule/@random47b2476e0dd39/gallery15', 'DSC00523.JPG', '', 0, 'image/jpeg', 1, 1202870590, 154016, 0, 1202870590, 640, 480, 1),
(33, 'files/imagegallerymodule/@random47b2476e0dd39/gallery15', 'DSC00524.JPG', '', 0, 'image/jpeg', 1, 1202870590, 152027, 0, 1202870590, 640, 480, 1),
(34, 'files/imagegallerymodule/@random47b2476e0dd39/gallery15', 'fred_and_adam.jpg', '', 0, 'image/jpeg', 1, 1202870660, 144065, 0, 1202870660, 640, 480, 1),
(35, 'files/imagegallerymodule/@random47b2476e0dd39/gallery15', 'phillip_and_fred.jpg', '', 0, 'image/jpeg', 1, 1202870661, 142380, 0, 1202870661, 640, 480, 1),
(36, 'files/listingmodule/@random47dacf258de2c', '1205523012_3387_turf_houses.jpg', '', 0, 'image/jpeg', 1, 1205523012, 81368, 0, 1205523012, 760, 570, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_file_collection`
-- 

DROP TABLE IF EXISTS `exponent_file_collection`;
CREATE TABLE IF NOT EXISTS `exponent_file_collection` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_file_collection`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_formbuilder_address`
-- 

DROP TABLE IF EXISTS `exponent_formbuilder_address`;
CREATE TABLE IF NOT EXISTS `exponent_formbuilder_address` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(100) collate utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_formbuilder_address`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_formbuilder_control`
-- 

DROP TABLE IF EXISTS `exponent_formbuilder_control`;
CREATE TABLE IF NOT EXISTS `exponent_formbuilder_control` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `caption` varchar(150) collate utf8_unicode_ci NOT NULL,
  `form_id` int(11) NOT NULL,
  `data` text collate utf8_unicode_ci NOT NULL,
  `rank` int(8) NOT NULL,
  `is_readonly` tinyint(1) NOT NULL,
  `is_static` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_formbuilder_control`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_formbuilder_form`
-- 

DROP TABLE IF EXISTS `exponent_formbuilder_form`;
CREATE TABLE IF NOT EXISTS `exponent_formbuilder_form` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `table_name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `is_email` tinyint(1) NOT NULL,
  `is_saved` tinyint(1) NOT NULL,
  `response` text collate utf8_unicode_ci NOT NULL,
  `submitbtn` varchar(100) collate utf8_unicode_ci NOT NULL,
  `resetbtn` varchar(100) collate utf8_unicode_ci NOT NULL,
  `subject` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_formbuilder_form`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_formbuilder_report`
-- 

DROP TABLE IF EXISTS `exponent_formbuilder_report`;
CREATE TABLE IF NOT EXISTS `exponent_formbuilder_report` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `text` text collate utf8_unicode_ci NOT NULL,
  `form_id` int(11) NOT NULL,
  `column_names` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_formbuilder_report`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_geo_country`
-- 

DROP TABLE IF EXISTS `exponent_geo_country`;
CREATE TABLE IF NOT EXISTS `exponent_geo_country` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `iso_code_2letter` varchar(2) collate utf8_unicode_ci NOT NULL,
  `iso_code_3letter` varchar(3) collate utf8_unicode_ci NOT NULL,
  `iso_code_number` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_geo_country`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_geo_region`
-- 

DROP TABLE IF EXISTS `exponent_geo_region`;
CREATE TABLE IF NOT EXISTS `exponent_geo_region` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `code` varchar(20) collate utf8_unicode_ci NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_geo_region`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_group`
-- 

DROP TABLE IF EXISTS `exponent_group`;
CREATE TABLE IF NOT EXISTS `exponent_group` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `inclusive` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_group`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_groupmembership`
-- 

DROP TABLE IF EXISTS `exponent_groupmembership`;
CREATE TABLE IF NOT EXISTS `exponent_groupmembership` (
  `member_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `is_admin` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_groupmembership`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_grouppermission`
-- 

DROP TABLE IF EXISTS `exponent_grouppermission`;
CREATE TABLE IF NOT EXISTS `exponent_grouppermission` (
  `gid` int(11) NOT NULL,
  `permission` varchar(20) collate utf8_unicode_ci NOT NULL,
  `module` varchar(100) collate utf8_unicode_ci NOT NULL,
  `source` varchar(100) collate utf8_unicode_ci NOT NULL,
  `internal` varchar(100) collate utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_grouppermission`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_guestbook_comment`
-- 

DROP TABLE IF EXISTS `exponent_guestbook_comment`;
CREATE TABLE IF NOT EXISTS `exponent_guestbook_comment` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL,
  `title` varchar(150) collate utf8_unicode_ci NOT NULL,
  `body` text collate utf8_unicode_ci NOT NULL,
  `poster` int(11) NOT NULL,
  `posted` int(14) NOT NULL,
  `edited` int(14) NOT NULL,
  `editor` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_guestbook_comment`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_guestbook_post`
-- 

DROP TABLE IF EXISTS `exponent_guestbook_post`;
CREATE TABLE IF NOT EXISTS `exponent_guestbook_post` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(150) collate utf8_unicode_ci NOT NULL,
  `body` text collate utf8_unicode_ci NOT NULL,
  `name` varchar(150) collate utf8_unicode_ci NOT NULL,
  `email` varchar(150) collate utf8_unicode_ci NOT NULL,
  `url` varchar(150) collate utf8_unicode_ci NOT NULL,
  `posted` int(14) NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_guestbook_post`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_guestbookmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_guestbookmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_guestbookmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `allow_comments` tinyint(1) NOT NULL,
  `items_per_page` int(8) NOT NULL,
  `wysiwyg` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_guestbookmodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_imagegallery_gallery`
-- 

DROP TABLE IF EXISTS `exponent_imagegallery_gallery`;
CREATE TABLE IF NOT EXISTS `exponent_imagegallery_gallery` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(150) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `box_size` int(8) NOT NULL,
  `pop_size` int(8) NOT NULL,
  `perpage` int(8) NOT NULL,
  `perrow` int(8) NOT NULL,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

-- 
-- Dumping data for table `exponent_imagegallery_gallery`
-- 

INSERT IGNORE INTO `exponent_imagegallery_gallery` (`id`, `name`, `description`, `box_size`, `pop_size`, `perpage`, `perrow`, `location_data`) VALUES 
(1, 'My trip to Australia', '<p>I had a blast in Australia, and her''s my pictures to prove it!</p>', 100, 500, 12, 3, ''),
(2, 'dsfdsfsdf', '', 100, 500, 0, 0, ''),
(3, '', '', 0, 0, 0, 0, ''),
(4, '', '', 0, 0, 0, 0, ''),
(5, '', '', 0, 0, 0, 0, ''),
(6, '', '', 0, 0, 0, 0, ''),
(7, '', '', 0, 0, 0, 0, ''),
(8, '', '', 0, 0, 0, 0, ''),
(9, 'dasddsad', '', 100, 500, 0, 0, ''),
(10, '', '', 0, 0, 0, 0, ''),
(15, 'Late Saturday night at Fred''s getting the release ready', '<p>Nothing better than gettin'' your geek on late on a Saturday night!&nbsp; Here''s some shots of Fred Dirkse, Adam Kessler and Phillip Ball of the OIC Group working to get Coolwater themed up.</p>', 100, 450, 12, 3, 'O:8:"stdClass":3:{s:3:"mod";s:18:"imagegallerymodule";s:3:"src";s:20:"@random47b2476e0dd39";s:3:"int";s:0:"";}');

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_imagegallery_image`
-- 

DROP TABLE IF EXISTS `exponent_imagegallery_image`;
CREATE TABLE IF NOT EXISTS `exponent_imagegallery_image` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(150) collate utf8_unicode_ci NOT NULL,
  `alt` varchar(25) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `file_id` int(11) NOT NULL,
  `thumbnail` varchar(200) collate utf8_unicode_ci NOT NULL,
  `enlarged` varchar(200) collate utf8_unicode_ci NOT NULL,
  `gallery_id` int(11) NOT NULL,
  `posted` int(14) NOT NULL,
  `rank` int(8) NOT NULL,
  `newwindow` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

-- 
-- Dumping data for table `exponent_imagegallery_image`
-- 

INSERT IGNORE INTO `exponent_imagegallery_image` (`id`, `name`, `alt`, `description`, `file_id`, `thumbnail`, `enlarged`, `gallery_id`, `posted`, `rank`, `newwindow`) VALUES 
(16, 'Adam observing Fred', 'Adam observing Fred', '<p>Since Fred is using Windows Vista, Adam is showing him how to use a computer.</p>', 31, 'DSC00521_thumb.JPG', 'DSC00521_popup.JPG', 15, 0, 5, 1),
(15, 'Fred finds all this very amusing', '', '<p>What''s so funny Fred?</p>', 30, 'DSC00520_thumb.JPG', 'DSC00520_popup.JPG', 15, 0, 3, 1),
(13, 'A very excited Phillip', 'A very excited Phillip', '<p>Phillip looks like he''s really excited to be in front of a computer on a Saturday night...</p>', 28, 'DSC00518_thumb.JPG', 'DSC00518_popup.JPG', 15, 0, 2, 1),
(14, 'Badger Phil', 'Badger Phil', '<p>Phillip doing his best impression of a large rodent of some kind. A badger perhaps?</p>', 29, 'DSC00519_thumb.JPG', 'DSC00519_popup.JPG', 15, 0, 4, 1),
(17, 'A busy man', 'Adam Kessler', '<p>Adam diligently working away while Fred again takes notes on how to use a computer.</p>', 32, 'DSC00523_thumb.JPG', 'DSC00523_popup.JPG', 15, 0, 6, 1),
(18, 'Adam''s Magic', 'Magic Trick', '<p>Adam attempts to dazzle Fred with some magic.&nbsp; Fred responds with an awkward stare.</p>', 33, 'DSC00524_thumb.JPG', 'DSC00524_popup.JPG', 15, 0, 7, 1),
(19, 'Fred and Adam', 'Fred and Adam', '<p>Fred Dirkse and Adam Kessler getting set up.</p>', 34, 'fred_and_adam_thumb.jpg', 'fred_and_adam_popup.jpg', 15, 0, 1, 1),
(20, 'Phillip and Fred', 'Phillip Ball and Fred Dir', '<p>Phillip on the Left anf Fred on the right getting Coolwater warmed up and ready for a night of fine tuning.</p>', 35, 'phillip_and_fred_thumb.jpg', 'phillip_and_fred_popup.jpg', 15, 0, 0, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_imagegallerymodule_config`
-- 

DROP TABLE IF EXISTS `exponent_imagegallerymodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_imagegallerymodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `multiple_galleries` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_imagegallerymodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_inbox_contact`
-- 

DROP TABLE IF EXISTS `exponent_inbox_contact`;
CREATE TABLE IF NOT EXISTS `exponent_inbox_contact` (
  `id` int(11) NOT NULL auto_increment,
  `owner` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `display_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `notes` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_inbox_contact`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_inbox_contactbanned`
-- 

DROP TABLE IF EXISTS `exponent_inbox_contactbanned`;
CREATE TABLE IF NOT EXISTS `exponent_inbox_contactbanned` (
  `id` int(11) NOT NULL auto_increment,
  `owner` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_inbox_contactbanned`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_inbox_contactlist`
-- 

DROP TABLE IF EXISTS `exponent_inbox_contactlist`;
CREATE TABLE IF NOT EXISTS `exponent_inbox_contactlist` (
  `id` int(11) NOT NULL auto_increment,
  `owner` int(11) NOT NULL,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_inbox_contactlist`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_inbox_contactlist_member`
-- 

DROP TABLE IF EXISTS `exponent_inbox_contactlist_member`;
CREATE TABLE IF NOT EXISTS `exponent_inbox_contactlist_member` (
  `list_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_inbox_contactlist_member`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_inbox_userconfig`
-- 

DROP TABLE IF EXISTS `exponent_inbox_userconfig`;
CREATE TABLE IF NOT EXISTS `exponent_inbox_userconfig` (
  `id` int(11) NOT NULL,
  `forward` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_inbox_userconfig`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_linklist_link`
-- 

DROP TABLE IF EXISTS `exponent_linklist_link`;
CREATE TABLE IF NOT EXISTS `exponent_linklist_link` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  `rank` int(8) NOT NULL,
  `name` varchar(250) collate utf8_unicode_ci NOT NULL,
  `url` text collate utf8_unicode_ci NOT NULL,
  `opennew` tinyint(1) NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `exponent_linklist_link`
-- 

INSERT IGNORE INTO `exponent_linklist_link` (`id`, `location_data`, `rank`, `name`, `url`, `opennew`, `description`) VALUES 
(1, 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', 0, 'YAHOO! UI', 'http://developer.yahoo.com/yui/', 1, 'Since Exponent now ships with and uses at the core The YAHOO! User Interface javascript library, this is a great resource for Exponent Developers.'),
(2, 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', 0, 'Exponent', 'http://exponentcms.org', 1, 'Where you came from :)'),
(3, 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', 0, 'Firefox', 'http://firefox.com', 1, ''),
(4, 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', 0, 'PDPhoto.org', 'http://www.pdphoto.org/', 1, ''),
(5, 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', 0, 'Squidfingers', 'http://www.squidfingers.com/patterns/', 1, ''),
(6, 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', 0, 'A List Apart', 'http://www.alistapart.com/', 1, ''),
(7, 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', 0, 'CSS Remix', 'http://www.cssremix.com/', 1, ''),
(8, 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', 0, 'CSS Mania', 'http://www.cssmania/', 1, ''),
(9, 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', 0, 'OIC Group, Inc.', 'http://www.oicgroup.net', 1, 'Web design, web development, web hosting and content management with Exponent CMS.'),
(10, 'O:8:"stdClass":3:{s:3:"mod";s:18:"hotro_onlinemodule";s:3:"src";s:20:"@random4815dea590596";s:3:"int";s:0:"";}', 0, 'Đặng Tín Trung', 'immanuel192', 1, 'dfsa'),
(11, 'O:8:"stdClass":3:{s:3:"mod";s:18:"hotro_onlinemodule";s:3:"src";s:20:"@random4815dea590596";s:3:"int";s:0:"";}', 0, 'Lan Anh', 'lananh.lovely', 1, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_linklistmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_linklistmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_linklistmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  `orderby` varchar(100) collate utf8_unicode_ci NOT NULL,
  `orderhow` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_linklistmodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_listing`
-- 

DROP TABLE IF EXISTS `exponent_listing`;
CREATE TABLE IF NOT EXISTS `exponent_listing` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `file_id` int(11) NOT NULL,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `summary` text collate utf8_unicode_ci NOT NULL,
  `body` text collate utf8_unicode_ci NOT NULL,
  `rank` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `exponent_listing`
-- 

INSERT IGNORE INTO `exponent_listing` (`id`, `location_data`, `file_id`, `name`, `summary`, `body`, `rank`) VALUES 
(1, 'O:8:"stdClass":3:{s:3:"mod";s:13:"listingmodule";s:3:"src";s:20:"@random47c5b4903a1a6";s:3:"int";s:0:"";}', 0, 'asdfasdfasfd', 'asdfasdfasdf', '<p>asdfasdfasdf</p>', 0),
(2, 'O:8:"stdClass":3:{s:3:"mod";s:13:"listingmodule";s:3:"src";s:20:"@random47dacf258de2c";s:3:"int";s:0:"";}', 36, 'The Turfhouse', 'Sie haben strudel pukein blitz, hans verboten thinken, in noodle undervear thinken. Poopsie sauerkraut ya, hinder hinder dummkopf, poopsie. ', '<p>Sie haben strudel pukein blitz, hans verboten thinken, in noodle undervear thinken. Poopsie sauerkraut ya, hinder hinder dummkopf, poopsie.</p>\r\n<p>Verboten corkin, spritz noodle spritz keepin haben. Bar keepin bar, deutsch bar relaxern lookinpeepers gestalt, du spitzen er. Wunderbar zur flippin heinee thinken underbite er. Gestalt ich du auf hinder lookinpeepers ya kaputt mitten, gewerkin.</p>\r\n<p>Kaputt, spritz und und nicht, deutsch nine pukein strudel oompaloomp kaputt, wearin, thinken floppern. Uber rubberneckin bin, weiner du heinee, octoberfest footzerstompen handercloppen kaputt glockenspiel auf, meister. Floppern yodel nine, waltz stoppern, weiner thinken. Haben sauerkraut poopsie haus floppern wearin nutske, underbite, sightseerin buerger deutsch pretzel. Poken buerger poopsie keepin in, heiden oompaloomp.</p>', 0),
(3, 'O:8:"stdClass":3:{s:3:"mod";s:13:"listingmodule";s:3:"src";s:20:"@random47dacf258de2c";s:3:"int";s:0:"";}', 0, 'An example without an image', 'Round-up rockinchair, maw liniment diesel fishin'' hollarin'' put rightly dirt, feathered moonshine reckon, thar. Greasy polecat cowpoke aunt stole, fricaseed rat rattler greasy tar. \r\n', '<p>Round-up rockinchair, maw liniment diesel fishin'' hollarin'' put rightly dirt, feathered moonshine reckon, thar. Greasy polecat cowpoke aunt stole, fricaseed rat rattler greasy tar.</p>\r\n<p>Ass go darn simple tin drunk yonder git panhandle dogs. Out townfolk rattler jumpin'' inbred penny sherrif. Overalls rodeo penny, me, old skedaddled snakeoil that bible. Liniment, far havin'' dogs mush liar throwed hospitality, bull a java confounded.</p>\r\n<p>Frontporch wild foreclose wuz hogtied hogtied grandpa coonskin no in down feathered beat. Rustle highway promenade confounded bacon jig broke, is foreclose them outhouse hillbilly than guzzled how. Truck tractor jail cousin mashed no fiddle, jezebel, dogs mobilehome drunk, backwoods. Crop simple barrel go wild kickin'' sam-hell boobtube. Barn me squalor bootleg crazy maw fancy fancy wrestlin'' them fancy muster ails.</p>\r\n<p>&nbsp;</p>', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_listingmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_listingmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_listingmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `exponent_listingmodule_config`
-- 

INSERT IGNORE INTO `exponent_listingmodule_config` (`id`, `location_data`) VALUES 
(1, 'O:8:"stdClass":3:{s:3:"mod";s:13:"listingmodule";s:3:"src";s:20:"@random47dacf258de2c";s:3:"int";s:0:"";}');

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_locationref`
-- 

DROP TABLE IF EXISTS `exponent_locationref`;
CREATE TABLE IF NOT EXISTS `exponent_locationref` (
  `module` varchar(100) collate utf8_unicode_ci NOT NULL,
  `source` varchar(100) collate utf8_unicode_ci NOT NULL,
  `internal` varchar(100) collate utf8_unicode_ci NOT NULL,
  `refcount` int(8) NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`module`,`source`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_locationref`
-- 

INSERT IGNORE INTO `exponent_locationref` (`module`, `source`, `internal`, `refcount`, `description`) VALUES 
('navigationmodule', '', '', 1000, ''),
('loginmodule', '', '', 1000, ''),
('previewmodule', '', '', 1000, ''),
('containermodule', '@left1', '', 1000, ''),
('containermodule', '@section1', '', 1000, ''),
('containermodule', '@right1', '', 1000, ''),
('textmodule', 'footer', '', 1000, ''),
('administrationmodule', '', '', 1, ''),
('textmodule', '@random419404caefcef', '', 1, ''),
('textmodule', '@random4194052be45c3', '', 1, ''),
('textmodule', '@random419405c1966ac', '', 1, ''),
('textmodule', '@random419406fa74f12', '', 1, ''),
('containermodule', '@left2', '', 1000, ''),
('containermodule', '@section2', '', 1000, ''),
('containermodule', '@right2', '', 1000, ''),
('containermodule', '@left3', '', 1000, ''),
('containermodule', '@section3', '', 1000, ''),
('containermodule', '@right3', '', 1000, ''),
('textmodule', '@random4194077998a8b', '', 1, ''),
('containermodule', '@left4', '', 1000, ''),
('containermodule', '@section4', '', 1000, ''),
('containermodule', '@right4', '', 1000, ''),
('textmodule', '@random419407b5c3260', '', 1, ''),
('containermodule', '@left7', '', 1000, ''),
('containermodule', '@section7', '', 1000, ''),
('containermodule', '@right7', '', 1000, ''),
('containermodule', '@left6', '', 1000, ''),
('containermodule', '@section6', '', 1000, ''),
('containermodule', '@right6', '', 1000, ''),
('textmodule', '@random41940859f0402', '', 2, ''),
('containermodule', '@left5', '', 1000, ''),
('containermodule', '@section5', '', 1000, ''),
('containermodule', '@right5', '', 1000, ''),
('textmodule', '@random47ae60f9710c1', '', 1, ''),
('weblogmodule', '@random41940a4020842', '', 2, ''),
('newsmodule', '@random41940a897e943', '', 3, ''),
('containermodule', '@left9', '', 1000, ''),
('imagegallerymodule', '@random47b2476e0dd39', '', 1, ''),
('contactmodule', '@random41940cfd10647', '', 2, ''),
('textmodule', '@random41940d1e14455', '', 2, ''),
('containermodule', '@left8', '', 1000, ''),
('containermodule', '@section8', '', 1000, ''),
('containermodule', '@right8', '', 1000, ''),
('containermodule', '@section9', '', 1000, ''),
('containermodule', '@right9', '', 1000, ''),
('containermodule', '@section11', '', 1000, ''),
('calendarmodule', '@random4198072c7e088', '', 1, ''),
('containermodule', '@left', '', 1000, ''),
('textmodule', 'welcometext', '', 1000, ''),
('textmodule', 'bluepanel', '', 1000, ''),
('containermodule', '@rightsidebar1', '', 1000, ''),
('containermodule', '@rightsidebar2', '', 999, ''),
('containermodule', '@rightsidebar7', '', 999, ''),
('containermodule', '@rightsidebar3', '', 1000, ''),
('containermodule', '@rightsidebar6', '', 1000, ''),
('containermodule', '@rightsidebar5', '', 1000, ''),
('containermodule', '@rightsidebar4', '', 1000, ''),
('calendarmodule', '@random45c39275942d0', '', 1, ''),
('navigationmodule', '@top', '', 1000, ''),
('containermodule', '@footer', '', 1000, ''),
('administrationmodule', '@random4797672dc6ea6', '', 1, ''),
('previewmodule', '@random4797672dc6ea6', '', 1000, ''),
('searchmodule', '@random47977a9d212f9', '', 1, ''),
('textmodule', '', '', 1000, ''),
('linklistmodule', '@random4797dbd1d2212', '', 1, ''),
('textmodule', '@random47ae62abd87cb', '', 1, ''),
('textmodule', '@random479a38d73523f', '', 1, ''),
('containermodule', '@section12', '', 1000, ''),
('containermodule', '@section13', '', 999, ''),
('containermodule', '@section10', '', 1000, ''),
('navigationmodule', '@random47ae7a369eab3', '', 1, ''),
('containermodule', '@section14', '', 999, ''),
('containermodule', '@section15', '', 999, ''),
('resourcesmodule', '@random47aeb9717f6f5', '', -1, ''),
('resourcesmodule', '@random41940ceb78dbb', '', 1, ''),
('containermodule', '@section16', '', 1000, ''),
('containermodule', '@section17', '', 1000, ''),
('textmodule', '@random47dacae9e1b86', '', 1, ''),
('listingmodule', '@random47dacf258de2c', '', 1, ''),
('hotro_onlinemodule', '@random4815dea590596', '', 1, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_mimetype`
-- 

DROP TABLE IF EXISTS `exponent_mimetype`;
CREATE TABLE IF NOT EXISTS `exponent_mimetype` (
  `id` int(11) NOT NULL auto_increment,
  `mimetype` varchar(100) collate utf8_unicode_ci NOT NULL,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `icon` varchar(100) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `exponent_mimetype`
-- 

INSERT IGNORE INTO `exponent_mimetype` (`id`, `mimetype`, `name`, `icon`) VALUES 
(1, 'text/plain', 'Plain Text', 'document.png'),
(2, 'image/jpeg', 'JPEG Image', 'image.png'),
(3, 'image/gif', 'GIF Image', 'image.png'),
(4, 'image/png', 'PNG (Portable Network Graphics) Image', 'image.png'),
(5, 'application/pdf', 'PDF Document', 'pdf.png'),
(6, 'application/vnd.sun.xml.writer', 'Open Office Document', 'txt2.png');

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_modstate`
-- 

DROP TABLE IF EXISTS `exponent_modstate`;
CREATE TABLE IF NOT EXISTS `exponent_modstate` (
  `module` varchar(100) collate utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_modstate`
-- 

INSERT IGNORE INTO `exponent_modstate` (`module`, `active`) VALUES 
('administrationmodule', 1),
('addressbookmodule', 1),
('calendarmodule', 1),
('contactmodule', 1),
('newsmodule', 1),
('imagemanagermodule', 0),
('previewmodule', 1),
('inboxmodule', 0),
('resourcesmodule', 1),
('weblogmodule', 1),
('textmodule', 1),
('listingmodule', 1),
('searchmodule', 1),
('navigationmodule', 1),
('linklistmodule', 1),
('imagegallerymodule', 1),
('snippetmodule', 1),
('hotro_onlinemodule', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_newsitem`
-- 

DROP TABLE IF EXISTS `exponent_newsitem`;
CREATE TABLE IF NOT EXISTS `exponent_newsitem` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `title` varchar(200) collate utf8_unicode_ci NOT NULL,
  `internal_name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `summary` text collate utf8_unicode_ci NOT NULL,
  `body` text collate utf8_unicode_ci NOT NULL,
  `publish` int(14) NOT NULL,
  `unpublish` int(14) NOT NULL,
  `posted` int(14) NOT NULL,
  `poster` int(11) NOT NULL,
  `edited` int(14) NOT NULL,
  `editor` int(11) NOT NULL,
  `approved` int(8) NOT NULL,
  `tags` text collate utf8_unicode_ci NOT NULL,
  `is_featured` tinyint(1) NOT NULL,
  `file_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds news items' AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `exponent_newsitem`
-- 

INSERT IGNORE INTO `exponent_newsitem` (`id`, `location_data`, `title`, `internal_name`, `summary`, `body`, `publish`, `unpublish`, `posted`, `poster`, `edited`, `editor`, `approved`, `tags`, `is_featured`, `file_id`) VALUES 
(6, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', 'Exponent 0.97 Alpha', '', '', '<p>We''re finally putting the finishing touches on what appears to be a very promising release.</p>\r\n<p>verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit.</p>\r\n<p>verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit.</p>', 0, 0, 1203130856, 1, 1203130856, 0, 1, 'a:0:{}', 0, 0),
(7, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', 'YUI 2.5 Coming Soon to Exponent', '7', '', '<p>YUI 2.5 was releases in February this year.&nbsp; This current alpha release of Expoonent ships with the 2.4.1 version of YUI, but stay tuned, as plans and development have already begun under the 2.5 version of YUI with Exponent. Exponent 0.97 Beta will ship with the YAHOO User Interface version 2.5. </p>\r\n<p>verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit.</p>\r\n<p>verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit.</p>', 0, 0, 1203131007, 1, 1205530874, 1, 1, 'a:2:{i:0;s:1:"5";i:1;s:1:"3";}', 0, 0),
(3, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', 'Another News Post', '', '', '\r\n\r\nTorqueo eros in, eu refoveo ideo nimis obruo, ut. Facilisi vel tum molior dolore, esse consequat, ex utrum aliquip facilisi. <br /><br />Opes,\r\ncamur roto abdo tum gilvus jugis nulla tincidunt quidem sagaciter. Mara\r\nymo nostrud magna populus quidne. Jumentum jugis, nullus, lenis feugiat\r\nconsequat pertineo tation. Nulla nibh ne, saluto ne saluto, at delenit\r\nimmitto fere. <br /><br />Et illum distineo antehabeo enim quadrum enim at\r\nquidne quod. Odio natu et ad illum valde proprius iustum meus, fere\r\nconsequat sed lobortis. Validus, esse vulputate, ideo iusto luptatum\r\nsit opto. <br /><br />Nulla iriure minim sit elit, quidem facilisi nisl.\r\nFeugiat neo aliquip praesent jus suscipit euismod paulatim capio foras\r\nin haero. Qui epulae, vulputate tristique vel letatio iustum luptatum\r\nsagaciter similis exerci vero. Enim gemino letalis molior eligo\r\nletalis. Ullamcorper macto quidem turpis causa eros nimis mara duis\r\nmelior pecus interdico, tristique, demoveo. <br /><br />Ex fatua iriure\r\nesse, obruo cogo regula wisi. Incassum incassum vel, lobortis valetudo\r\nconventio verto. Luptatum nutus vero, ullamcorper opes abico, fatua\r\nadipiscing erat lobortis tation letatio tation, accumsan. Nulla mara\r\npraesent duis nibh haero dignissim neo, blandit tristique eum. Neo\r\ndolore pertineo eros, reprobo euismod pagus pala pneum esse sagaciter\r\ndefui ex lobortis. Dolus roto genitus humo transverbero vero turpis, os\r\ndistineo, nullus dolore. <br /><br />Ulciscor hos antehabeo esse valetudo\r\ncausa, pneum aliquip gilvus, refoveo eu. Exputo, vindico nulla\r\nconsequat hendrerit dolore iusto humo, macto sit esca aliquip facilisis\r\nad. <br /><br />Nulla abluo feugiat in, foras commoveo facilisi eu decet. Mauris feugiat duis te velit distineo similis eu gravis ad, tamen. <br /><br />Facilisi\r\naliquip quae in diam ullamcorper et occuro vel, iriure quidne. Refoveo\r\nletalis, consequat duis ex defui enim, jugis abdo foras. Suscipere\r\ndolore ut molior augue, facilisis pneum vereor saluto, ea lobortis.\r\nTum, esca demoveo usitas, sed, esse. Quod vel ratis sagaciter eros\r\njumentum ullamcorper causa. Esse nulla dignissim qui at uxor erat defui\r\ndolor ideo. Ea secundum natu ut ex quadrum odio vulpes secundum\r\nconsequat praesent virtus saluto. Causa ut interdico dignissim illum\r\nnunc premo delenit facilisi.\r\n', 0, 0, 1100221133, 1, 1100221133, 1, 1, '', 0, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_newsitem_wf_info`
-- 

DROP TABLE IF EXISTS `exponent_newsitem_wf_info`;
CREATE TABLE IF NOT EXISTS `exponent_newsitem_wf_info` (
  `real_id` int(11) NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `current_major` int(8) NOT NULL,
  `current_minor` int(8) NOT NULL,
  `open_slots` int(8) NOT NULL,
  `updated` int(14) NOT NULL,
  `current_state_data` text collate utf8_unicode_ci NOT NULL,
  `policy_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Workflow Summary table for newsitem';

-- 
-- Dumping data for table `exponent_newsitem_wf_info`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_newsitem_wf_revision`
-- 

DROP TABLE IF EXISTS `exponent_newsitem_wf_revision`;
CREATE TABLE IF NOT EXISTS `exponent_newsitem_wf_revision` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `title` varchar(200) collate utf8_unicode_ci NOT NULL,
  `internal_name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `summary` text collate utf8_unicode_ci NOT NULL,
  `body` text collate utf8_unicode_ci NOT NULL,
  `publish` int(14) NOT NULL,
  `unpublish` int(14) NOT NULL,
  `posted` int(14) NOT NULL,
  `poster` int(11) NOT NULL,
  `edited` int(14) NOT NULL,
  `editor` int(11) NOT NULL,
  `approved` int(8) NOT NULL,
  `tags` text collate utf8_unicode_ci NOT NULL,
  `is_featured` tinyint(1) NOT NULL,
  `file_id` int(11) NOT NULL,
  `wf_major` int(8) NOT NULL,
  `wf_minor` int(8) NOT NULL,
  `wf_original` int(11) NOT NULL,
  `wf_state_data` text collate utf8_unicode_ci NOT NULL,
  `wf_approved` tinyint(1) NOT NULL,
  `wf_type` int(8) NOT NULL,
  `wf_updated` int(14) NOT NULL,
  `wf_comment` text collate utf8_unicode_ci NOT NULL,
  `wf_user_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Workflow Revisions table for newsitem' AUTO_INCREMENT=16 ;

-- 
-- Dumping data for table `exponent_newsitem_wf_revision`
-- 

INSERT IGNORE INTO `exponent_newsitem_wf_revision` (`id`, `location_data`, `title`, `internal_name`, `summary`, `body`, `publish`, `unpublish`, `posted`, `poster`, `edited`, `editor`, `approved`, `tags`, `is_featured`, `file_id`, `wf_major`, `wf_minor`, `wf_original`, `wf_state_data`, `wf_approved`, `wf_type`, `wf_updated`, `wf_comment`, `wf_user_id`) VALUES 
(3, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', 'Another News Post', '', '', '\r\n\r\nTorqueo eros in, eu refoveo ideo nimis obruo, ut. Facilisi vel tum molior dolore, esse consequat, ex utrum aliquip facilisi. <br /><br />Opes,\r\ncamur roto abdo tum gilvus jugis nulla tincidunt quidem sagaciter. Mara\r\nymo nostrud magna populus quidne. Jumentum jugis, nullus, lenis feugiat\r\nconsequat pertineo tation. Nulla nibh ne, saluto ne saluto, at delenit\r\nimmitto fere. <br /><br />Et illum distineo antehabeo enim quadrum enim at\r\nquidne quod. Odio natu et ad illum valde proprius iustum meus, fere\r\nconsequat sed lobortis. Validus, esse vulputate, ideo iusto luptatum\r\nsit opto. <br /><br />Nulla iriure minim sit elit, quidem facilisi nisl.\r\nFeugiat neo aliquip praesent jus suscipit euismod paulatim capio foras\r\nin haero. Qui epulae, vulputate tristique vel letatio iustum luptatum\r\nsagaciter similis exerci vero. Enim gemino letalis molior eligo\r\nletalis. Ullamcorper macto quidem turpis causa eros nimis mara duis\r\nmelior pecus interdico, tristique, demoveo. <br /><br />Ex fatua iriure\r\nesse, obruo cogo regula wisi. Incassum incassum vel, lobortis valetudo\r\nconventio verto. Luptatum nutus vero, ullamcorper opes abico, fatua\r\nadipiscing erat lobortis tation letatio tation, accumsan. Nulla mara\r\npraesent duis nibh haero dignissim neo, blandit tristique eum. Neo\r\ndolore pertineo eros, reprobo euismod pagus pala pneum esse sagaciter\r\ndefui ex lobortis. Dolus roto genitus humo transverbero vero turpis, os\r\ndistineo, nullus dolore. <br /><br />Ulciscor hos antehabeo esse valetudo\r\ncausa, pneum aliquip gilvus, refoveo eu. Exputo, vindico nulla\r\nconsequat hendrerit dolore iusto humo, macto sit esca aliquip facilisis\r\nad. <br /><br />Nulla abluo feugiat in, foras commoveo facilisi eu decet. Mauris feugiat duis te velit distineo similis eu gravis ad, tamen. <br /><br />Facilisi\r\naliquip quae in diam ullamcorper et occuro vel, iriure quidne. Refoveo\r\nletalis, consequat duis ex defui enim, jugis abdo foras. Suscipere\r\ndolore ut molior augue, facilisis pneum vereor saluto, ea lobortis.\r\nTum, esca demoveo usitas, sed, esse. Quod vel ratis sagaciter eros\r\njumentum ullamcorper causa. Esse nulla dignissim qui at uxor erat defui\r\ndolor ideo. Ea secundum natu ut ex quadrum odio vulpes secundum\r\nconsequat praesent virtus saluto. Causa ut interdico dignissim illum\r\nnunc premo delenit facilisi.\r\n', 0, 0, 1100221133, 1, 0, 0, 0, '', 0, 0, 1, 0, 3, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100221133, '', 0),
(14, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', 'YUI 2.5 Coming Soon!', '7', '', '<p>YUI 2.5 Coming in February, 2008.&nbsp; We''re all looking forward to some really exciting new features!</p>\r\n<p>verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit.</p>\r\n<p>verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit.</p>', 0, 0, 1203131007, 1, 1203131049, 1, 2, 'a:2:{i:0;s:1:"5";i:1;s:1:"3";}', 0, 0, 2, 0, 7, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1203131049, '', 1),
(12, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', 'Exponent 0.97 Alpha', '', '', '<p>We''re finally putting the finishing touches on what appears to be a very promising release.</p>\r\n<p>verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit.</p>\r\n<p>verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit.</p>', 0, 0, 1203130856, 1, 1203130856, 0, 0, 'a:0:{}', 0, 0, 1, 0, 6, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1203130856, '', 1),
(13, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', '', '', '', '<p>YUI 2.5 Coming in February, 2008.&nbsp; We''re all looking forward to some really exciting new features!</p>\r\n<p>verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit.</p>\r\n<p>verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit.</p>', 0, 0, 1203131007, 1, 1203131007, 0, 0, 'a:0:{}', 0, 0, 1, 0, 7, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1203131007, '', 1),
(15, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', 'YUI 2.5 Coming Soon to Exponent', '7', '', '<p>YUI 2.5 was releases in February this year.&nbsp; This current alpha release of Expoonent ships with the 2.4.1 version of YUI, but stay tuned, as plans and development have already begun under the 2.5 version of YUI with Exponent. Exponent 0.97 Beta will ship with the YAHOO User Interface version 2.5. </p>\r\n<p>verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit.</p>\r\n<p>verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit.</p>', 0, 0, 1203131007, 1, 1205530874, 1, 2, 'a:2:{i:0;s:1:"5";i:1;s:1:"3";}', 0, 0, 3, 0, 7, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1205530874, '', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_newsmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_newsmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_newsmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `sortorder` varchar(100) collate utf8_unicode_ci NOT NULL,
  `sortfield` varchar(100) collate utf8_unicode_ci NOT NULL,
  `item_limit` int(8) NOT NULL,
  `enable_rss` tinyint(1) NOT NULL,
  `enable_tags` tinyint(1) NOT NULL,
  `aggregate` text collate utf8_unicode_ci NOT NULL,
  `collections` text collate utf8_unicode_ci NOT NULL,
  `group_by_tags` tinyint(1) NOT NULL,
  `show_tags` text collate utf8_unicode_ci NOT NULL,
  `feed_title` varchar(75) collate utf8_unicode_ci NOT NULL,
  `feed_desc` varchar(200) collate utf8_unicode_ci NOT NULL,
  `pull_rss` tinyint(1) NOT NULL,
  `rss_feed` text collate utf8_unicode_ci NOT NULL,
  `rss_cachetime` int(8) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10)),
  KEY `collections` (`collections`(10)),
  KEY `show_tags` (`show_tags`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `exponent_newsmodule_config`
-- 

INSERT IGNORE INTO `exponent_newsmodule_config` (`id`, `location_data`, `sortorder`, `sortfield`, `item_limit`, `enable_rss`, `enable_tags`, `aggregate`, `collections`, `group_by_tags`, `show_tags`, `feed_title`, `feed_desc`, `pull_rss`, `rss_feed`, `rss_cachetime`) VALUES 
(1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', 'DESC', 'posted', 2, 1, 1, '0', 'a:1:{i:0;s:1:"1";}', 0, 'a:0:{}', 'Sample Exponent CMS News', '', 0, 'a:0:{}', 0),
(2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random4797dfd4b2dc5";s:3:"int";s:0:"";}', 'DESC', 'posted', 10, 0, 0, '0', 'a:0:{}', 0, 'a:0:{}', '', '', 0, '', 3600);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_pagemodule_config`
-- 

DROP TABLE IF EXISTS `exponent_pagemodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_pagemodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `handle_php` int(8) NOT NULL,
  `file_id` int(11) NOT NULL,
  `filepath` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_pagemodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_passreset_token`
-- 

DROP TABLE IF EXISTS `exponent_passreset_token`;
CREATE TABLE IF NOT EXISTS `exponent_passreset_token` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `token` varchar(150) collate utf8_unicode_ci NOT NULL,
  `expires` int(14) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_passreset_token`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_poll_answer`
-- 

DROP TABLE IF EXISTS `exponent_poll_answer`;
CREATE TABLE IF NOT EXISTS `exponent_poll_answer` (
  `id` int(11) NOT NULL auto_increment,
  `question_id` int(11) NOT NULL,
  `answer` text collate utf8_unicode_ci NOT NULL,
  `rank` int(8) NOT NULL,
  `vote_count` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_poll_answer`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_poll_question`
-- 

DROP TABLE IF EXISTS `exponent_poll_question`;
CREATE TABLE IF NOT EXISTS `exponent_poll_question` (
  `id` int(11) NOT NULL auto_increment,
  `question` varchar(255) collate utf8_unicode_ci NOT NULL,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `open_results` tinyint(1) NOT NULL,
  `open_voting` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_poll_question`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_poll_timeblock`
-- 

DROP TABLE IF EXISTS `exponent_poll_timeblock`;
CREATE TABLE IF NOT EXISTS `exponent_poll_timeblock` (
  `id` int(11) NOT NULL auto_increment,
  `question_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip_hash` varchar(64) collate utf8_unicode_ci NOT NULL,
  `lock_expires` int(14) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_poll_timeblock`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_profileextension`
-- 

DROP TABLE IF EXISTS `exponent_profileextension`;
CREATE TABLE IF NOT EXISTS `exponent_profileextension` (
  `id` int(11) NOT NULL auto_increment,
  `extension` varchar(100) collate utf8_unicode_ci NOT NULL,
  `rank` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `exponent_profileextension`
-- 

INSERT IGNORE INTO `exponent_profileextension` (`id`, `extension`, `rank`) VALUES 
(1, 'addressextension', 0),
(2, 'phoneextension', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_resourceitem`
-- 

DROP TABLE IF EXISTS `exponent_resourceitem`;
CREATE TABLE IF NOT EXISTS `exponent_resourceitem` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  `file_id` int(11) NOT NULL,
  `flock_owner` int(11) NOT NULL,
  `approved` int(8) NOT NULL,
  `posted` int(14) NOT NULL,
  `poster` int(11) NOT NULL,
  `edited` int(14) NOT NULL,
  `editor` int(11) NOT NULL,
  `rank` int(8) NOT NULL,
  `num_downloads` int(8) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds resource items' AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `exponent_resourceitem`
-- 

INSERT IGNORE INTO `exponent_resourceitem` (`id`, `name`, `description`, `location_data`, `file_id`, `flock_owner`, `approved`, `posted`, `poster`, `edited`, `editor`, `rank`, `num_downloads`) VALUES 
(5, 'PDF Example', '<p>Here is an example PDF resource.</p>', 'O:8:"stdClass":3:{s:3:"mod";s:15:"resourcesmodule";s:3:"src";s:20:"@random41940ceb78dbb";s:3:"int";s:0:"";}', 7, 0, 1, 0, 0, 1204432601, 1, 0, 0),
(6, 'Open Office Document', 'The Exponent Resource Manager can handle a wide variety of file types, not just images and plain text files.', 'O:8:"stdClass":3:{s:3:"mod";s:15:"resourcesmodule";s:3:"src";s:20:"@random41940ceb78dbb";s:3:"int";s:0:"";}', 8, 0, 1, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_resourceitem_wf_info`
-- 

DROP TABLE IF EXISTS `exponent_resourceitem_wf_info`;
CREATE TABLE IF NOT EXISTS `exponent_resourceitem_wf_info` (
  `real_id` int(11) NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `current_major` int(8) NOT NULL,
  `current_minor` int(8) NOT NULL,
  `open_slots` int(8) NOT NULL,
  `updated` int(14) NOT NULL,
  `current_state_data` text collate utf8_unicode_ci NOT NULL,
  `policy_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Workflow Summary table for resourceitem';

-- 
-- Dumping data for table `exponent_resourceitem_wf_info`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_resourceitem_wf_revision`
-- 

DROP TABLE IF EXISTS `exponent_resourceitem_wf_revision`;
CREATE TABLE IF NOT EXISTS `exponent_resourceitem_wf_revision` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  `file_id` int(11) NOT NULL,
  `flock_owner` int(11) NOT NULL,
  `approved` int(8) NOT NULL,
  `posted` int(14) NOT NULL,
  `poster` int(11) NOT NULL,
  `edited` int(14) NOT NULL,
  `editor` int(11) NOT NULL,
  `rank` int(8) NOT NULL,
  `num_downloads` int(8) NOT NULL,
  `wf_major` int(8) NOT NULL,
  `wf_minor` int(8) NOT NULL,
  `wf_original` int(11) NOT NULL,
  `wf_state_data` text collate utf8_unicode_ci NOT NULL,
  `wf_approved` tinyint(1) NOT NULL,
  `wf_type` int(8) NOT NULL,
  `wf_updated` int(14) NOT NULL,
  `wf_comment` text collate utf8_unicode_ci NOT NULL,
  `wf_user_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Workflow Revisions table for resourceitem' AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `exponent_resourceitem_wf_revision`
-- 

INSERT IGNORE INTO `exponent_resourceitem_wf_revision` (`id`, `name`, `description`, `location_data`, `file_id`, `flock_owner`, `approved`, `posted`, `poster`, `edited`, `editor`, `rank`, `num_downloads`, `wf_major`, `wf_minor`, `wf_original`, `wf_state_data`, `wf_approved`, `wf_type`, `wf_updated`, `wf_comment`, `wf_user_id`) VALUES 
(6, 'Open Office Document', 'The Exponent Resource Manager can handle a wide variety of file types, not just images and plain text files.', 'O:8:"stdClass":3:{s:3:"mod";s:15:"resourcesmodule";s:3:"src";s:20:"@random41940ceb78dbb";s:3:"int";s:0:"";}', 8, 0, 2, 0, 0, 0, 0, 0, 0, 1, 0, 6, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100483107, '', 0),
(5, 'PDF Example', 'Here is an exmaple PDF resource.\r\n', 'O:8:"stdClass":3:{s:3:"mod";s:15:"resourcesmodule";s:3:"src";s:20:"@random41940ceb78dbb";s:3:"int";s:0:"";}', 7, 0, 2, 0, 0, 0, 0, 0, 0, 1, 0, 5, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100483043, '', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_resourcesmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_resourcesmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_resourcesmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `allow_anon_downloads` tinyint(1) NOT NULL,
  `feed_title` varchar(75) collate utf8_unicode_ci NOT NULL,
  `feed_desc` varchar(200) collate utf8_unicode_ci NOT NULL,
  `enable_podcasting` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `exponent_resourcesmodule_config`
-- 

INSERT IGNORE INTO `exponent_resourcesmodule_config` (`id`, `location_data`, `allow_anon_downloads`, `feed_title`, `feed_desc`, `enable_podcasting`) VALUES 
(1, 'O:8:"stdClass":3:{s:3:"mod";s:15:"resourcesmodule";s:3:"src";s:20:"@random41940ceb78dbb";s:3:"int";s:0:"";}', 1, '', '', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_rotator_item`
-- 

DROP TABLE IF EXISTS `exponent_rotator_item`;
CREATE TABLE IF NOT EXISTS `exponent_rotator_item` (
  `id` int(11) NOT NULL auto_increment,
  `text` mediumtext collate utf8_unicode_ci NOT NULL,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_rotator_item`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_rssmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_rssmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_rssmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `url` varchar(250) collate utf8_unicode_ci NOT NULL,
  `item_limit` int(8) NOT NULL,
  `age` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_rssmodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_search`
-- 

DROP TABLE IF EXISTS `exponent_search`;
CREATE TABLE IF NOT EXISTS `exponent_search` (
  `id` int(11) NOT NULL auto_increment,
  `original_id` int(11) NOT NULL,
  `title` text collate utf8_unicode_ci NOT NULL,
  `posted` int(14) NOT NULL,
  `body` text collate utf8_unicode_ci NOT NULL,
  `keywords` text collate utf8_unicode_ci NOT NULL,
  `view_link` text collate utf8_unicode_ci NOT NULL,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  `view_perm` varchar(250) collate utf8_unicode_ci NOT NULL,
  `category` varchar(150) collate utf8_unicode_ci NOT NULL,
  `ref_module` varchar(100) collate utf8_unicode_ci NOT NULL,
  `ref_type` varchar(100) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10)),
  KEY `ref_module` (`ref_module`(10)),
  KEY `ref_type` (`ref_type`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=43 ;

-- 
-- Dumping data for table `exponent_search`
-- 

INSERT IGNORE INTO `exponent_search` (`id`, `original_id`, `title`, `posted`, `body`, `keywords`, `view_link`, `location_data`, `view_perm`, `category`, `ref_module`, `ref_type`) VALUES 
(1, 1, ' Example Calendar Event ', 0, ' This is an example calendar event. ', '', '', 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random4198072c7e088";s:3:"int";s:0:"";}', '', 'Events', 'calendarmodule', 'calendar'),
(3, 3, ' ... Later That Day ', 0, ' This event shows that it is possible to have more than one event per day. ', '', '', 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random4198072c7e088";s:3:"int";s:0:"";}', '', 'Events', 'calendarmodule', 'calendar'),
(4, 4, ' Example Event ', 0, ' This is an example calendar event. ', '', '', 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}', '', 'Events', 'calendarmodule', 'calendar'),
(5, 1, ' YAHOO! UI ', 0, ' Since Exponent now ships with and uses at the core The YAHOO! User Interface javascript library, this is a great resource for Exponent Developers. ', '', '', 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', '', 'Links', 'linklistmodule', 'linklist_link'),
(6, 2, ' Exponent ', 0, ' Where you came from :) ', '', '', 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', '', 'Links', 'linklistmodule', 'linklist_link'),
(7, 3, ' Firefox ', 0, '  ', '', '', 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', '', 'Links', 'linklistmodule', 'linklist_link'),
(8, 4, ' PDPhoto.org ', 0, '  ', '', '', 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', '', 'Links', 'linklistmodule', 'linklist_link'),
(9, 5, ' Squidfingers ', 0, '  ', '', '', 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', '', 'Links', 'linklistmodule', 'linklist_link'),
(10, 6, ' A List Apart ', 0, '  ', '', '', 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', '', 'Links', 'linklistmodule', 'linklist_link'),
(11, 7, ' CSS Remix ', 0, '  ', '', '', 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', '', 'Links', 'linklistmodule', 'linklist_link'),
(12, 8, ' CSS Mania ', 0, '  ', '', '', 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', '', 'Links', 'linklistmodule', 'linklist_link'),
(13, 9, ' OIC Group, Inc. ', 0, ' Web design, web development, web hosting and content management with Exponent CMS. ', '', '', 'O:8:"stdClass":3:{s:3:"mod";s:14:"linklistmodule";s:3:"src";s:20:"@random4797dbd1d2212";s:3:"int";s:0:"";}', '', 'Links', 'linklistmodule', 'linklist_link'),
(14, 1, 'Home', 0, ' When you are logged into the system as the administrator, you will see the administration module appear below.  This is a simple text module, which is viewable on the Home page section.  &quot;Content Management&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With point-and-click ease, updating your site has never been easier! Point and Click Ease With minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents. Design Flexibility Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use. Dynamic Navigation and Content Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing! Robust User Management IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.   	The module below is a News Module, shown using the ''Summary'' view.  Visit the News section to see the same module and same content shown using a different view.  This is an example of content reusability.   Home | Contact Us | Site-map ', ' About the Admin Mod Simple Text Mod Welcome to Exponent CMS About News Feeds ', 'Home', '', '', 'Webpages', 'navigationmodule', 'section'),
(17, 4, 'Events', 0, ' The large calendar in the main body of this page and the mini-calendar below share the same content. ', ' ', 'events', '', '', 'Webpages', 'navigationmodule', 'section'),
(18, 5, 'My Blog', 0, ' &copy; 2008 Your Company | Design by: styleshout | Theme by: OIC Group ', ' ', 'my-blog', '', '', 'Webpages', 'navigationmodule', 'section'),
(21, 12, 'Slideshow Module', 0, '', '', 'slideshow-module', '', '', 'Webpages', 'navigationmodule', 'section'),
(36, 1, ' Example News Item ', 0, ' verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit. verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit. verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit. ', '', 'index.php?module=newsmodule&action=view&id=1', 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', '', 'News', 'newsmodule', 'newsitem'),
(37, 6, ' Exponent 0.97 Alpha ', 0, ' We''re finally putting the finishing touches on what appears to be a very promising release. verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit. verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit. ', '', 'index.php?module=newsmodule&action=view&id=6', 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', '', 'News', 'newsmodule', 'newsitem'),
(32, 7, ' aaaaaaa ', 0, ' asdfasdf ', '', 'index.php?module=resourcesmodule&action=view&id=7', 'O:8:"stdClass":3:{s:3:"mod";s:15:"resourcesmodule";s:3:"src";s:20:"@random47aebadc759f2";s:3:"int";s:0:"";}', '', 'File Resources', 'resourcesmodule', 'resourceitem'),
(25, 5, ' PDF Example ', 0, ' Here is an exmaple PDF resource.  ', '', 'index.php?module=resourcesmodule&action=view&id=5', 'O:8:"stdClass":3:{s:3:"mod";s:15:"resourcesmodule";s:3:"src";s:20:"@random41940ceb78dbb";s:3:"int";s:0:"";}', '', 'File Resources', 'resourcesmodule', 'resourceitem'),
(26, 6, ' Open Office Document ', 0, ' The Exponent Resource Manager can handle a wide variety of file types, not just images and plain text files. ', '', 'index.php?module=resourcesmodule&action=view&id=6', 'O:8:"stdClass":3:{s:3:"mod";s:15:"resourcesmodule";s:3:"src";s:20:"@random41940ceb78dbb";s:3:"int";s:0:"";}', '', 'File Resources', 'resourcesmodule', 'resourceitem'),
(42, 7, ' YUI 2.5 Coming Soon to Exponent ', 0, ' YUI 2.5 was releases in February this year.&nbsp; This current alpha release of Expoonent ships with the 2.4.1 version of YUI, but stay tuned, as plans and development have already begun under the 2.5 version of YUI with Exponent. Exponent 0.97 Beta will ship with the YAHOO User Interface version 2.5.  verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit. verto opes gilvus neque te hendrerittamen, odio. Tum at paulatim, delenit genitus erat eu roto in immittoillum qui. Ut gravis meus, tation capto nisl, oppeto ut quod. Turpisconsequat neo gemino, olim ut si mauris in, in nostrud tinciduntulciscor. At ut letalis, nobis ille persto opto lobortis vero quis nisleuismod fatua brevitas. Camur sagaciter mos, adipiscing, amet huic eudemoveo eros magna iaceo, causa, saepius delenit. ', '', 'index.php?module=newsmodule&action=view&id=7', 'O:8:"stdClass":3:{s:3:"mod";s:10:"newsmodule";s:3:"src";s:20:"@random41940a897e943";s:3:"int";s:0:"";}', '', 'News', 'newsmodule', 'newsitem'),
(41, 5, ' asdfasdf ', 0, ' asdfasdf ', '', '', 'O:8:"stdClass":3:{s:3:"mod";s:14:"calendarmodule";s:3:"src";s:20:"@random45c39275942d0";s:3:"int";s:0:"";}', '', 'Events', 'calendarmodule', 'calendar');

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_search_extension`
-- 

DROP TABLE IF EXISTS `exponent_search_extension`;
CREATE TABLE IF NOT EXISTS `exponent_search_extension` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  `extension` varchar(200) collate utf8_unicode_ci NOT NULL,
  `rank` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_search_extension`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_searchmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_searchmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_searchmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `is_categorized` tinyint(1) NOT NULL,
  `modules` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_searchmodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_section`
-- 

DROP TABLE IF EXISTS `exponent_section`;
CREATE TABLE IF NOT EXISTS `exponent_section` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `sef_name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `subtheme` varchar(100) collate utf8_unicode_ci NOT NULL,
  `public` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `new_window` tinyint(1) NOT NULL,
  `parent` int(11) NOT NULL,
  `rank` int(8) NOT NULL,
  `page_title` varchar(200) collate utf8_unicode_ci NOT NULL,
  `keywords` text collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `alias_type` int(8) NOT NULL,
  `external_link` text collate utf8_unicode_ci NOT NULL,
  `internal_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `parent` (`parent`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

-- 
-- Dumping data for table `exponent_section`
-- 

INSERT IGNORE INTO `exponent_section` (`id`, `name`, `sef_name`, `subtheme`, `public`, `active`, `new_window`, `parent`, `rank`, `page_title`, `keywords`, `description`, `alias_type`, `external_link`, `internal_id`) VALUES 
(1, 'Home', 'home', '', 1, 1, 0, 0, 0, '', '', '', 0, '', 0),
(3, 'News', 'news', '', 1, 1, 0, 0, 1, '', '', '', 0, '', 0),
(4, 'Events', 'events', 'Full Body', 1, 1, 0, 0, 2, '', '', '', 0, '', 0),
(5, 'My Blog', 'my-blog', '', 1, 1, 0, 0, 3, '', '', '', 0, '', 0),
(6, 'Other Cool Modules', 'other-cool-modules', '', 1, 0, 0, 0, 4, '', '', '', 0, '', 0),
(10, 'Site Map', 'site-map', '', 1, 1, 0, -1, 0, '', '', '', 0, '', 0),
(11, 'Image Gallery', 'image-gallery', '', 1, 1, 0, 6, 0, '', '', '', 0, '', 0),
(12, 'Resource Module', 'resource-module', '', 1, 1, 0, 6, 1, '', '', '', 0, '', 0),
(16, 'Contact Module', 'contact-module', '', 1, 1, 0, 6, 2, '', '', '', 0, '', 0),
(17, 'Listing Module', 'listing-module', '', 1, 1, 0, 6, 3, '', '', '', 0, '', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_section_template`
-- 

DROP TABLE IF EXISTS `exponent_section_template`;
CREATE TABLE IF NOT EXISTS `exponent_section_template` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `subtheme` varchar(100) collate utf8_unicode_ci NOT NULL,
  `public` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `parent` int(11) NOT NULL,
  `rank` int(8) NOT NULL,
  `page_title` varchar(200) collate utf8_unicode_ci NOT NULL,
  `keywords` text collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_section_template`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_sectionref`
-- 

DROP TABLE IF EXISTS `exponent_sectionref`;
CREATE TABLE IF NOT EXISTS `exponent_sectionref` (
  `id` int(11) NOT NULL auto_increment,
  `module` varchar(100) collate utf8_unicode_ci NOT NULL,
  `source` varchar(100) collate utf8_unicode_ci NOT NULL,
  `internal` varchar(100) collate utf8_unicode_ci NOT NULL,
  `section` int(11) NOT NULL,
  `refcount` int(8) NOT NULL,
  `is_original` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=80 ;

-- 
-- Dumping data for table `exponent_sectionref`
-- 

INSERT IGNORE INTO `exponent_sectionref` (`id`, `module`, `source`, `internal`, `section`, `refcount`, `is_original`) VALUES 
(1, 'administrationmodule', '', '', 1, 1, 0),
(2, 'textmodule', '@random419404caefcef', '', 1, 1, 0),
(3, 'textmodule', '@random4194052be45c3', '', 1, 1, 0),
(4, 'textmodule', '@random4194056cde0cd', '', 1, 1, 0),
(5, 'textmodule', '@random419405c1966ac', '', 1, 1, 0),
(6, 'imagemanagermodule', '@random41940634b401d', '', 1, 1, 0),
(7, 'textmodule', '@random419406fa74f12', '', 1, 1, 0),
(9, 'textmodule', '@random4194077998a8b', '', 3, 1, 0),
(10, 'textmodule', '@random419407b5c3260', '', 4, 1, 0),
(12, 'textmodule', '@random41940859f0402', '', 6, 1, 0),
(16, 'weblogmodule', '@random41940a4020842', '', 5, 2, 0),
(17, 'newsmodule', '@random41940a897e943', '', 3, 3, 0),
(19, 'resourcesmodule', '@random41940ceb78dbb', '', 6, 1, 0),
(20, 'contactmodule', '@random41940cfd10647', '', 6, 1, 0),
(21, 'textmodule', '@random41940d1e14455', '', 6, 1, 0),
(50, 'containermodule', '@section11', '', 11, 1000, 1),
(24, 'calendarmodule', '@random4198072c7e088', '', 4, 1, 0),
(25, 'textmodule', 'bluepanel', '', 1, 1000, 1),
(26, 'containermodule', '@rightsidebar1', '', 1, 1000, 1),
(29, 'containermodule', '@rightsidebar3', '', 3, 1000, 1),
(30, 'containermodule', '@rightsidebar6', '', 6, 1000, 1),
(31, 'containermodule', '@rightsidebar5', '', 5, 1000, 1),
(32, 'containermodule', '@rightsidebar4', '', 4, 1000, 1),
(34, 'calendarmodule', '@random45c39275942d0', '', 4, 1, 1),
(36, 'navigationmodule', '@top', '', 1, 1000, 1),
(37, 'containermodule', '@footer', '', 1, 1000, 1),
(38, 'administrationmodule', '@random4797672dc6ea6', '', 1, 1, 1),
(39, 'previewmodule', '@random4797672dc6ea6', '', 1, 1000, 1),
(40, 'searchmodule', '@random47977a9d212f9', '', 1, 1, 1),
(41, 'textmodule', '', '', 1, 1000, 1),
(42, 'navigationmodule', '@random4797d7a01f403', '', 1, 1, 1),
(43, 'linklistmodule', '@random4797dbd1d2212', '', 1, 1, 1),
(44, 'newsmodule', '@random4797dfd4b2dc5', '', 1, 1, 1),
(46, 'textmodule', '@random479a38d73523f', '', 5, 1, 1),
(53, 'textmodule', '@random47ae60f9710c1', '', 11, 1, 1),
(54, 'textmodule', '@random47ae62abd87cb', '', 11, 1, 1),
(55, 'containermodule', '@section12', '', 12, 1000, 1),
(57, 'containermodule', '@section10', '', 10, 1000, 1),
(58, 'navigationmodule', '@random47ae7a369eab3', '', 10, 1, 1),
(64, 'imagegallerymodule', '@random47b2476e0dd39', '', 11, 1, 1),
(66, 'textmodule', '@random41940859f0402', '', 12, 1, 0),
(67, 'resourcesmodule', '@random41940ceb78dbb', '', 12, 1, 1),
(68, 'containermodule', '@section16', '', 16, 1000, 1),
(70, 'textmodule', '@random41940d1e14455', '', 16, 1, 0),
(71, 'contactmodule', '@random41940cfd10647', '', 16, 1, 0),
(72, 'containermodule', '@section17', '', 17, 1000, 1),
(73, 'textmodule', '@random47dacae9e1b86', '', 17, 1, 1),
(74, 'listingmodule', '@random47dacf258de2c', '', 17, 1, 1),
(75, 'listingmodule', '@random47dade03d43cd', '', 17, 0, 1),
(77, 'listingmodule', '@random47daffe017c68', '', 17, 0, 1),
(78, 'addressbookmodule', '@random47db00fa6b48b', '', 17, 0, 1),
(79, 'hotro_onlinemodule', '@random4815dea590596', '', 16, 1, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_sessionticket`
-- 

DROP TABLE IF EXISTS `exponent_sessionticket`;
CREATE TABLE IF NOT EXISTS `exponent_sessionticket` (
  `ticket` varchar(23) collate utf8_unicode_ci NOT NULL,
  `uid` int(11) NOT NULL,
  `last_active` int(14) NOT NULL,
  `refresh` tinyint(1) NOT NULL,
  `ip_address` varchar(15) collate utf8_unicode_ci NOT NULL,
  `start_time` int(14) NOT NULL,
  `browser` varchar(250) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`ticket`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_sessionticket`
-- 

INSERT IGNORE INTO `exponent_sessionticket` (`ticket`, `uid`, `last_active`, `refresh`, `ip_address`, `start_time`, `browser`) VALUES 
('48156e9c8cc418.61339061', 0, 1209367760, 1, '127.0.0.1', 1209364124, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi-VN; rv:1.8.1) Gecko/20061010 Firefox/2.0'),
('48157cd932f261.44520998', 1, 1209446042, 0, '127.0.0.1', 1209367769, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; vi-VN; rv:1.8.1) Gecko/20061010 Firefox/2.0');

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_simplepollmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_simplepollmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_simplepollmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `thank_you_message` text collate utf8_unicode_ci NOT NULL,
  `already_voted_message` text collate utf8_unicode_ci NOT NULL,
  `voting_closed_message` text collate utf8_unicode_ci NOT NULL,
  `anonymous_timeout` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_simplepollmodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_slideshow_slide`
-- 

DROP TABLE IF EXISTS `exponent_slideshow_slide`;
CREATE TABLE IF NOT EXISTS `exponent_slideshow_slide` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `file_id` int(11) NOT NULL,
  `scale` int(8) NOT NULL,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_slideshow_slide`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_slideshowmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_slideshowmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_slideshowmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `delay` int(8) NOT NULL,
  `random` tinyint(1) NOT NULL,
  `img_width` int(8) NOT NULL,
  `img_height` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_slideshowmodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_swfitem`
-- 

DROP TABLE IF EXISTS `exponent_swfitem`;
CREATE TABLE IF NOT EXISTS `exponent_swfitem` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `bgcolor` varchar(12) collate utf8_unicode_ci NOT NULL,
  `height` int(8) NOT NULL,
  `width` int(8) NOT NULL,
  `alignment` int(8) NOT NULL,
  `swf_id` int(11) NOT NULL,
  `alt_image_id` int(11) NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `loop_movie` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`(10)),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_swfitem`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_tag_collections`
-- 

DROP TABLE IF EXISTS `exponent_tag_collections`;
CREATE TABLE IF NOT EXISTS `exponent_tag_collections` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `allow_free_tags` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `exponent_tag_collections`
-- 

INSERT IGNORE INTO `exponent_tag_collections` (`id`, `name`, `description`, `allow_free_tags`) VALUES 
(1, 'Example Tags', 'These are some sample tags...just to show you how they work.', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_tags`
-- 

DROP TABLE IF EXISTS `exponent_tags`;
CREATE TABLE IF NOT EXISTS `exponent_tags` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `collection_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `collection_id` (`collection_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `exponent_tags`
-- 

INSERT IGNORE INTO `exponent_tags` (`id`, `name`, `collection_id`) VALUES 
(3, 'Shenanigans', 1),
(5, 'Alpaca', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_tasklist_task`
-- 

DROP TABLE IF EXISTS `exponent_tasklist_task`;
CREATE TABLE IF NOT EXISTS `exponent_tasklist_task` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  `name` varchar(250) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `priority` int(8) NOT NULL,
  `completion` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_tasklist_task`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_tasklistmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_tasklistmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_tasklistmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  `show_completed` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_tasklistmodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_textitem`
-- 

DROP TABLE IF EXISTS `exponent_textitem`;
CREATE TABLE IF NOT EXISTS `exponent_textitem` (
  `id` int(11) NOT NULL auto_increment,
  `text` mediumtext collate utf8_unicode_ci NOT NULL,
  `approved` int(8) NOT NULL,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Text Items' AUTO_INCREMENT=23 ;

-- 
-- Dumping data for table `exponent_textitem`
-- 

INSERT IGNORE INTO `exponent_textitem` (`id`, `text`, `approved`, `location_data`) VALUES 
(1, 'When you are logged into the system as the administrator, you will see\r\nthe administration module appear below.', 1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419404caefcef";s:3:"int";s:0:"";}'),
(2, 'This is a simple text module, which is viewable on the Home page\r\nsection.', 1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random4194052be45c3";s:3:"int";s:0:"";}'),
(4, '<p><img width="250" height="253" align="left" alt="" src="files/expbox.jpg" />&quot;<b>Content Management</b>&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With <i>point-and-click ease</i>, updating your site has never been easier!</p>\r\n<p>This is new <b>content</b>.</p>\r\n<h3>Point and Click Ease</h3>\r\n<p>With minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>\r\n<p>&nbsp;</p>', 1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}'),
(16, '<p><a href="index.php">Home</a> | <a href="contact-module">Contact Us</a> | <a href="site-map">Site-map</a></p>', 1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:0:"";s:3:"int";s:0:"";}'),
(6, 'The news module below contains several example news posts / press\r\nreleases. The module automatically formats your content with a Title,\r\nSummary, and ''Read More'' link. The summary is auto-generated by taking\r\nthe news post body content up to the first line break / carriage return.<br /><br />The\r\nsame news module below is also displayed in the right column on the\r\nhome page (for some themes) using a different ''view''. This is an\r\nexample of content reusability.\r\n', 1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random4194077998a8b";s:3:"int";s:0:"";}'),
(7, 'The large calendar in the main body of this page and the mini-calendar\r\nbelow share the same content.', 1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419407b5c3260";s:3:"int";s:0:"";}'),
(9, '\r\n	The following module is a Resource Module. It is used for\r\nfile-based resource management, such as documents, spreadsheets, MP3''s,\r\netc. <br /><br />There are several different views available, including those with and without file descriptions, and with and without icons.<br /><br />Uploading\r\nto a resource module is a very easy point and click operation. File\r\ntypes are determined by the mime type of the file (something that is automatically detected for you), and the icons\r\ndisplayed are configurable in the administration interface (File Types link under the Files Subsystem heading).<br /><br />The Resource Module also allows you to optionally ''Lock'' and ''Update'' resources, effective for document collaboration efforts.\r\n', 1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random41940859f0402";s:3:"int";s:0:"";}'),
(12, '\r\n	The module below is a News Module, shown using the ''Summary'' view.  Visit the <a title="News section" href="?section=3">News section</a> to see the same module and same content shown using a different view.  This is an example of content reusability.\r\n', 1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419406fa74f12";s:3:"int";s:0:"";}'),
(13, 'Contact Forms provide your website visitors with an easy method of getting in touch with you.', 1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random41940d1e14455";s:3:"int";s:0:"";}'),
(18, '<p style="text-align: center;">&copy; 2008 Your Company | Design by: <a href="http://www.styleshout.com/" target="_blank">styleshout</a> | Theme by: <a href="http://oicgroup.net">OIC Group</a></p>', 1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random479a38d73523f";s:3:"int";s:0:"";}'),
(20, '<div style="text-align: center;">Exponent CMS recommends using the Firefox browser.<br /><br />\r\n\r\n<script type="text/javascript">\r\n<!--\r\ngoogle_ad_client = "pub-9988965384511526";\r\ngoogle_ad_width = 125;\r\ngoogle_ad_height = 125;\r\ngoogle_ad_format = "125x125_as_rimg";\r\ngoogle_cpa_choice = "CAAQ9YCYhAIaCKRaB5-eKO08KK2293M";\r\ngoogle_ad_channel = "8893827061";\r\n//--></script>\r\n<script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" type="text/javascript">nbsp;</script>\r\n</div>', 1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random47ae60f9710c1";s:3:"int";s:0:"";}'),
(21, '<p>If you have coding, development, testing, documentation, or other skills to offer the Exponent Team, please visit our <a target="_blank" href="http://sourceforge.net/tracker/?group_id=118524&amp;atid=726871">contributions</a> section on sourceforge.net or contact the <a href="?section=119" title="Contact the Exponent CMS Developement Team">Exponent Development Team</a>.&nbsp; You may also donate to our project by using the button below.</p>\r\n<p><a href="http://sourceforge.net/donate/index.php?group_id=118524"><img width="88" height="32" border="0" alt="Support This Project" src="http://images.sourceforge.net/images/project-support.jpg" /> </a></p>', 1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random47ae62abd87cb";s:3:"int";s:0:"";}'),
(22, '<p>The listing module is a perfect module for displaying information like houses for relestate companies, books for libraries, job listings, company information, or anything else that could make use of a title, image, summary, and full description. This module allows items to be listed on one page, showing the title, summary, and optional image.&nbsp; Clicking any lising will then take you to view that listings full description and larger image.</p>', 1, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random47dacae9e1b86";s:3:"int";s:0:"";}');

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_textitem_wf_info`
-- 

DROP TABLE IF EXISTS `exponent_textitem_wf_info`;
CREATE TABLE IF NOT EXISTS `exponent_textitem_wf_info` (
  `real_id` int(11) NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `current_major` int(8) NOT NULL,
  `current_minor` int(8) NOT NULL,
  `open_slots` int(8) NOT NULL,
  `updated` int(14) NOT NULL,
  `current_state_data` text collate utf8_unicode_ci NOT NULL,
  `policy_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Workflow Summary table for textitem';

-- 
-- Dumping data for table `exponent_textitem_wf_info`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_textitem_wf_revision`
-- 

DROP TABLE IF EXISTS `exponent_textitem_wf_revision`;
CREATE TABLE IF NOT EXISTS `exponent_textitem_wf_revision` (
  `id` int(11) NOT NULL auto_increment,
  `text` mediumtext collate utf8_unicode_ci NOT NULL,
  `approved` int(8) NOT NULL,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  `wf_major` int(8) NOT NULL,
  `wf_minor` int(8) NOT NULL,
  `wf_original` int(11) NOT NULL,
  `wf_state_data` text collate utf8_unicode_ci NOT NULL,
  `wf_approved` tinyint(1) NOT NULL,
  `wf_type` int(8) NOT NULL,
  `wf_updated` int(14) NOT NULL,
  `wf_comment` text collate utf8_unicode_ci NOT NULL,
  `wf_user_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Workflow Revisions table for textitem' AUTO_INCREMENT=43 ;

-- 
-- Dumping data for table `exponent_textitem_wf_revision`
-- 

INSERT IGNORE INTO `exponent_textitem_wf_revision` (`id`, `text`, `approved`, `location_data`, `wf_major`, `wf_minor`, `wf_original`, `wf_state_data`, `wf_approved`, `wf_type`, `wf_updated`, `wf_comment`, `wf_user_id`) VALUES 
(1, 'When you are logged into the system as the administrator, you will see\r\nthe administration module appear below.', 0, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419404caefcef";s:3:"int";s:0:"";}', 1, 0, 1, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100219630, '', 0),
(2, 'This is a simple text module, which is viewable on the Home page\r\nsection.', 0, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random4194052be45c3";s:3:"int";s:0:"";}', 1, 0, 2, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100219716, '', 0),
(17, '<table rules="none" frame="void" border="0" style="border-style: none; width: 100%; background-image: none; float: none; text-align: left; vertical-align: top;">\r\n    <tbody>\r\n        <tr>\r\n            <td><img vspace="0" hspace="0" border="0" src="files/imagemanagermodule/@random41940634b401d/www3d_opt.jpg" alt="" /></td>\r\n            <td><br />\r\n            &quot;Content Management&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With point-and-clickease, updating your site has never been easier!</td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p><br />\r\n<span style="font-weight: bold;">Point and Click Ease</span><br />\r\nWith minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email.  With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.<br />\r\n<br style="font-weight: bold;" />\r\n<span style="font-weight: bold;">Design Flexibility</span><br />\r\nUnlike most content management systems, Exponent allows for complete design flexibility.  Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs.  All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.<br />\r\n<br />\r\n<span style="font-weight: bold;">Dynamic Navigation and Content</span><br />\r\nSite structure can be created on-the-fly in the browser, in just seconds.   Specialized modules provide the means to manage specific types of content, like Calendar events and News postings.  All content editing is done ''inline'', which means there is no need for a separate, back-end interface.  Simply surf to the content you want to maintain and start editing!<br />\r\n<br style="font-weight: bold;" />\r\n<span style="font-weight: bold;">Robust User Management</span><br />\r\nIT staff and managers can delegate site maintenance duties to any number of staff members, through user and gruop permissions.  Permissions can be set as restrictively or permissively as needed.</p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 3, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1170804298, '', 1),
(4, '\r\n<table rules="none" frame="void" border="0" style="border-style: none; width: 100%; background-image: none; float: none; text-align: left; vertical-align: top;"><tbody><tr><td><img src="files/imagemanagermodule/@random418210a40424e/www3d_opt.jpg" /><br /></td><td><br />\r\n&quot;Content Management&quot; is one of the biggest buzzwords on the lips of IT\r\nstaff and management alike. Exponent brings the power of maintaining a\r\nwebsite into the hands of nontechnical people. With point-and-click\r\nease, updating your site has never been easier!<br /></td></tr></tbody></table><br /><span style="font-weight: bold;">Point and Click Ease</span><br />With minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email.  With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.<br /><br style="font-weight: bold;" /><span style="font-weight: bold;">Design Flexibility</span><br />Unlike most content management systems, Exponent allows for complete design flexibility.  Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs.  All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.<br /><br /><span style="font-weight: bold;">Dynamic Navigation and Content</span><br />Site structure can be created on-the-fly in the browser, in just seconds.   Specialized modules provide the means to manage specific types of content, like Calendar events and News postings.  All content editing is done ''inline'', which means there is no need for a separate, back-end interface.  Simply surf to the content you want to maintain and start editing!<br /><br style="font-weight: bold;" /><span style="font-weight: bold;">Robust User Management</span><br />IT staff and managers can delegate site maintenance duties to any number of staff members, through user and gruop permissions.  Permissions can be set as restrictively or permissively as needed.<br />', 0, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 1, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100220127, '', 0),
(6, 'The news module below contains several example news posts / press\r\nreleases. The module automatically formats your content with a Title,\r\nSummary, and ''Read More'' link. The summary is auto-generated by taking\r\nthe news post body content up to the first line break / carriage return.<br /><br />The\r\nsame news module below is also displayed in the right column on the\r\nhome page (for some themes) using a different ''view''. This is an\r\nexample of content reusability.\r\n', 0, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random4194077998a8b";s:3:"int";s:0:"";}', 1, 0, 6, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100220317, '', 0),
(7, 'The large calendar in the main body of this page and the mini-calendar\r\nbelow share the same content.', 0, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419407b5c3260";s:3:"int";s:0:"";}', 1, 0, 7, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100220382, '', 0),
(9, '\r\n	The following module is a Resource Module. It is used for\r\nfile-based resource management, such as documents, spreadsheets, MP3''s,\r\netc. <br /><br />There are several different views available, including those with and without file descriptions, and with and without icons.<br /><br />Uploading\r\nto a resource module is a very easy point and click operation. File\r\ntypes are determined by the mime type of the file (something that is automatically detected for you), and the icons\r\ndisplayed are configurable in the administration interface (File Types link under the Files Subsystem heading).<br /><br />The Resource Module also allows you to optionally ''Lock'' and ''Update'' resources, effective for document collaboration efforts.\r\n', 0, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random41940859f0402";s:3:"int";s:0:"";}', 1, 0, 9, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100220511, '', 0),
(12, '\r\n	The module below is a News Module, shown using the ''Summary'' view.  Visit the <a title="News section" href="?section=3">News section</a> to see the same module and same content shown using a different view.  This is an example of content reusability.\r\n', 0, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419406fa74f12";s:3:"int";s:0:"";}', 1, 0, 12, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100221213, '', 0),
(13, 'Contact Forms provide your website visitors with an easy method of getting in touch with you.', 0, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random41940d1e14455";s:3:"int";s:0:"";}', 1, 0, 13, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100221904, '', 0),
(16, '\r\n<table rules="none" frame="void" border="0" style="border-style: none; width: 100%; background-image: none; float: none; text-align: left; vertical-align: top;"><tbody><tr><td><img vspace="0" hspace="0" border="0" src="files/imagemanagermodule/@random41940634b401d/www3d_opt.jpg" /><br /></td><td><br />\r\n&quot;Content Management&quot; is one of the biggest buzzwords on the lips of IT\r\nstaff and management alike. Exponent brings the power of maintaining a\r\nwebsite into the hands of nontechnical people. With point-and-click\r\nease, updating your site has never been easier!<br /></td></tr></tbody></table><br /><span style="font-weight: bold;">Point and Click Ease</span><br />With minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email.  With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.<br /><br style="font-weight: bold;" /><span style="font-weight: bold;">Design Flexibility</span><br />Unlike most content management systems, Exponent allows for complete design flexibility.  Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs.  All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.<br /><br /><span style="font-weight: bold;">Dynamic Navigation and Content</span><br />Site structure can be created on-the-fly in the browser, in just seconds.   Specialized modules provide the means to manage specific types of content, like Calendar events and News postings.  All content editing is done ''inline'', which means there is no need for a separate, back-end interface.  Simply surf to the content you want to maintain and start editing!<br /><br style="font-weight: bold;" /><span style="font-weight: bold;">Robust User Management</span><br />IT staff and managers can delegate site maintenance duties to any number of staff members, through user and gruop permissions.  Permissions can be set as restrictively or permissively as needed.<br />', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 2, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1100485700, '', 0),
(18, '<table rules="none" frame="void" border="0" style="border-style: none; width: 100%; background-image: none; float: none; text-align: left; vertical-align: top;">\r\n    <tbody>\r\n        <tr>\r\n            <td><img vspace="0" hspace="0" border="0" alt="" src="files/imagemanagermodule/@random41940634b401d/www3d_opt.jpg" /></td>\r\n            <td><br />\r\n            &quot;Content Management&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With point-and-click ease, updating your site has never been easier!</td>\r\n        </tr>\r\n    </tbody>\r\n</table>\r\n<p><br />\r\n<span style="font-weight: bold;">Point and Click Ease</span><br />\r\nWith minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email.  With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.<br />\r\n<br style="font-weight: bold;" />\r\n<span style="font-weight: bold;">Design Flexibility</span><br />\r\nUnlike most content management systems, Exponent allows for complete design flexibility.  Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs.  All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.<br />\r\n<br />\r\n<span style="font-weight: bold;">Dynamic Navigation and Content</span><br />\r\nSite structure can be created on-the-fly in the browser, in just seconds.   Specialized modules provide the means to manage specific types of content, like Calendar events and News postings.  All content editing is done ''inline'', which means there is no need for a separate, back-end interface.  Simply surf to the content you want to maintain and start editing!<br />\r\n<br style="font-weight: bold;" />\r\n<span style="font-weight: bold;">Robust User Management</span><br />\r\nIT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions.  Permissions can be set as restrictively or permissively as needed.</p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 4, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1170804353, '', 1),
(19, '<p><img width="175" hspace="5" height="167" align="left" src="/trunk/exponent/files/imagemanagermodule/@random41940634b401d/blocks_opt.jpg" alt="" />&quot;Content Management&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With point-and-click ease, updating your site has never been easier!</p>\r\n<h3><br />\r\n<br />\r\n&nbsp;</h3>\r\n<h3>Point and Click Ease</h3>\r\n<p>With minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 5, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1201105295, '', 1),
(20, '<p><img width="200" height="144" align="left" src="/trunk/exponent/files/imagemanagermodule/@random41940634b401d/www3d_opt.jpg" alt="" />&quot;<b>Content Management</b>&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With <i>point-and-click ease</i>, updating your site has never been easier!</p>\r\n<h3>Point and Click Ease</h3>\r\n<p>With minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 6, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1201105583, '', 1),
(21, '<p><img width="250" height="253" align="left" src="/trunk/exponent/files/expbox.png" alt="" />&quot;<b>Content Management</b>&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With <i>point-and-click ease</i>, updating your site has never been easier!</p>\r\n<h3>Point and Click Ease</h3>\r\n<p>With minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 7, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1201124208, '', 1),
(22, '<p><a href="index.php">Home</a></p>\r\n<p><a href="#">Contact Us</a></p>\r\n<p><a href="#">Site-map</a></p>', 0, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:0:"";s:3:"int";s:0:"";}', 1, 0, 16, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1201129356, '', 1),
(23, '<p><a href="index.php">Home</a> | <a href="#">Contact Us</a> | <a href="#">Site-map</a></p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:0:"";s:3:"int";s:0:"";}', 2, 0, 16, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1201129552, '', 1),
(25, '<p style="text-align: center;">&copy; 2008 Your Company | Design by: <a href="http://www.styleshout.com/" target="_blank">styleshout</a> | Theme by: <a href="http://oicgroup.net">OIC Group</a></p>', 0, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random479a38d73523f";s:3:"int";s:0:"";}', 1, 0, 18, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1201289607, '', 1),
(27, '<div style="text-align: center;">Exponent CMS recommends using the Firefox browser.<br /><br />\r\n\r\n<script type="text/javascript">\r\n<!--\r\ngoogle_ad_client = "pub-9988965384511526";\r\ngoogle_ad_width = 125;\r\ngoogle_ad_height = 125;\r\ngoogle_ad_format = "125x125_as_rimg";\r\ngoogle_cpa_choice = "CAAQ9YCYhAIaCKRaB5-eKO08KK2293M";\r\ngoogle_ad_channel = "8893827061";\r\n//--></script>\r\n<script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" type="text/javascript">nbsp;</script>\r\n</div>', 0, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random47ae60f9710c1";s:3:"int";s:0:"";}', 1, 0, 20, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1202610518, '', 1),
(29, '<p>If you have coding, development, testing, documentation, or other skills to offer the Exponent Team, please visit our <a target="_blank" href="http://sourceforge.net/tracker/?group_id=118524&amp;atid=726871">contributions</a> section on sourceforge.net or contact the <a href="?section=119" title="Contact the Exponent CMS Developement Team">Exponent Development Team</a>.&nbsp; You may also donate to our project by using the button below.</p>\r\n<p><a href="http://sourceforge.net/donate/index.php?group_id=118524"><img width="88" height="32" border="0" alt="Support This Project" src="http://images.sourceforge.net/images/project-support.jpg" /> </a></p>', 0, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random47ae62abd87cb";s:3:"int";s:0:"";}', 1, 0, 21, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1202610884, '', 1),
(30, '<p><a href="index.php">Home</a> | <a href="contact-us">Contact Us</a> | <a href="site-map">Site-map</a></p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:0:"";s:3:"int";s:0:"";}', 3, 0, 16, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1202616759, '', 1),
(31, '<p><img height="253" alt="" width="250" align="left" src="/trunk/exponent/files/expbox.png" />&quot;<b>Content Management</b>&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With <i>point-and-click ease</i>, updating your site has never been easier!</p>\r\n<h3>Point and Click Ease</h3>\r\n<p>With minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p><img height="80" hspace="5" width="71" align="left" vspace="5" alt="" src="/trunk/exponent/files/freddphooey.jpg" /></p>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>\r\n<p>&nbsp;</p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 8, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1202624050, '', 1),
(32, '<p><img height="253" alt="" width="250" align="left" src="/trunk/exponent/files/expbox.png" />&quot;<b>Content Management</b>&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With <i>point-and-click ease</i>, updating your site has never been easier!</p>\r\n<p>This is new <b>content</b>.</p>\r\n<h3>Point and Click Ease</h3>\r\n<p><a href="http://www.google.com">With minimal computer skills</a>, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p><img height="80" alt="" hspace="5" width="71" align="left" vspace="5" src="/trunk/exponent/files/freddphooey.jpg" /></p>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>\r\n<p>&nbsp;<img height="80" hspace="5" width="71" align="left" vspace="5" alt="" src="/trunk/exponent/files/freddphooey.jpg" /></p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 9, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1202624289, '', 1),
(33, '<p><img height="253" alt="" width="250" align="left" src="/trunk/exponent/files/expbox.png" />&quot;<b>Content Management</b>&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With <i>point-and-click ease</i>, updating your site has never been easier!</p>\r\n<p>This is new <b>content</b>.</p>\r\n<h3>Point and Click Ease</h3>\r\n<p><a href="http://www.google.com">With minimal computer skills</a>, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>\r\n<p><img height="80" alt="" hspace="5" width="71" align="left" vspace="5" src="/trunk/exponent/files/freddphooey.jpg" /></p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 10, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1202624369, '', 1),
(34, '<p><img height="253" alt="" width="250" align="left" src="/trunk/exponent/files/expbox.png" />&quot;<b>Content Management</b>&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With <i>point-and-click ease</i>, updating your site has never been easier!</p>\r\n<p>This is new <b>content</b>.</p>\r\n<h3>Point and Click Ease</h3>\r\n<p><a href="http://www.google.com">With minimal computer skills</a>, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p><img height="80" hspace="5" width="71" align="left" vspace="5" alt="" src="/trunk/exponent/files/freddphooey.jpg" /></p>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>\r\n<p>&nbsp;</p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 11, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1202624573, '', 1),
(35, '<p><img width="250" height="253" align="left" src="/trunk/exponent/files/expbox.jpg" alt="" />&quot;<b>Content Management</b>&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With <i>point-and-click ease</i>, updating your site has never been easier!</p>\r\n<p>This is new <b>content</b>.</p>\r\n<h3>Point and Click Ease</h3>\r\n<p><a href="http://www.google.com">With minimal computer skills</a>, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p><img width="71" vspace="5" hspace="5" height="80" align="left" src="/trunk/exponent/files/freddphooey.jpg" alt="" /></p>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>\r\n<p>&nbsp;</p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 12, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1202628671, '', 1),
(36, '<p><img width="250" height="253" align="left" alt="" src="/trunk/exponent/files/expbox.jpg" />&quot;<b>Content Management</b>&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With <i>point-and-click ease</i>, updating your site has never been easier!</p>\r\n<p>This is new <b>content</b>.</p>\r\n<h3>Point and Click Ease</h3>\r\n<p>With minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>\r\n<p>&nbsp;</p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 13, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1202831294, '', 1),
(37, '<p><img width="250" height="253" align="left" src="/trunk/exponent/files/expbox.jpg" alt="" />&quot;<b>Content Management</b>&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With <i>point-and-click ease</i>, updating your site has never been easier!</p>\r\n<p>This is new <b>content</b> and it rocks!</p>\r\n<h3>Point and Click Ease</h3>\r\n<p>With minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>\r\n<p>&nbsp;</p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 14, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1203132398, '', 1),
(38, '<p><img width="250" height="253" align="left" alt="" src="/trunk/exponent/files/expbox.jpg" />&quot;<b>Content Management</b>&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With <i>point-and-click ease</i>, updating your site has never been easier!</p>\r\n<p>This is new <b>content</b>.</p>\r\n<h3>Point and Click Ease</h3>\r\n<p>With minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>\r\n<p>&nbsp;</p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 15, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1203132618, '', 1),
(39, '<p><a href="index.php">Home</a> | <a href="contact-module">Contact Us</a> | <a href="site-map">Site-map</a></p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:0:"";s:3:"int";s:0:"";}', 4, 0, 16, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1205032549, '', 1),
(40, '<p><img width="250" height="253" align="left" src="/files/expbox.jpg" alt="" />&quot;<b>Content Management</b>&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With <i>point-and-click ease</i>, updating your site has never been easier!</p>\r\n<p>This is new <b>content</b>.</p>\r\n<h3>Point and Click Ease</h3>\r\n<p>With minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>\r\n<p>&nbsp;</p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 16, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1205092353, '', 1),
(41, '<p><img width="250" height="253" align="left" alt="" src="files/expbox.jpg" />&quot;<b>Content Management</b>&quot; is one of the biggest buzzwords on the lips of ITstaff and management alike. Exponent brings the power of maintaining awebsite into the hands of non-technical people. With <i>point-and-click ease</i>, updating your site has never been easier!</p>\r\n<p>This is new <b>content</b>.</p>\r\n<h3>Point and Click Ease</h3>\r\n<p>With minimal computer skills, you can securely login to your website anytime, anywhere, and update your site as easily as sending email. With Exponent''s advanced content editor, you can effortlessly create content, or cut and paste from almost any source, including PDFs and Word documents.</p>\r\n<h3>Design Flexibility</h3>\r\n<p>Unlike most content management systems, Exponent allows for complete design flexibility. Virtually any web layout can be integrated as an Exponent site. The system has been conceived and implemented based on strict data and design separation, which allows for virtually limitless designs. All module-based content utilizes design ''views'', which can be created easily and dropped into place for use.</p>\r\n<h3>Dynamic Navigation and Content</h3>\r\n<p>Site structure can be created on-the-fly in the browser, in just seconds. Specialized modules provide the means to manage specific types of content, like Calendar events and News postings. All content editing is done ''inline'', which means there is no need for a separate, back-end interface. Simply surf to the content you want to maintain and start editing!</p>\r\n<h3>Robust User Management</h3>\r\n<p>IT staff and managers can delegate site maintenance duties to any number of staff members, through user and group permissions. Permissions can be set as restrictively or permissively as needed.</p>\r\n<p>&nbsp;</p>', 2, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random419405c1966ac";s:3:"int";s:0:"";}', 17, 0, 4, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1205092390, '', 1),
(42, '<p>The listing module is a perfect module for displaying information like houses for relestate companies, books for libraries, job listings, company information, or anything else that could make use of a title, image, summary, and full description. This module allows items to be listed on one page, showing the title, summary, and optional image.&nbsp; Clicking any lising will then take you to view that listings full description and larger image.</p>', 0, 'O:8:"stdClass":3:{s:3:"mod";s:10:"textmodule";s:3:"src";s:20:"@random47dacae9e1b86";s:3:"int";s:0:"";}', 1, 0, 22, 'a:2:{i:0;a:1:{i:0;i:1;}i:1;a:1:{i:1;i:1;}}', 0, 10, 1205521925, '', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_toolbar_fckeditor`
-- 

DROP TABLE IF EXISTS `exponent_toolbar_fckeditor`;
CREATE TABLE IF NOT EXISTS `exponent_toolbar_fckeditor` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `data` text collate utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_toolbar_fckeditor`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_toolbar_tinymce`
-- 

DROP TABLE IF EXISTS `exponent_toolbar_tinymce`;
CREATE TABLE IF NOT EXISTS `exponent_toolbar_tinymce` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `data` text collate utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_toolbar_tinymce`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_toolbar_xinha`
-- 

DROP TABLE IF EXISTS `exponent_toolbar_xinha`;
CREATE TABLE IF NOT EXISTS `exponent_toolbar_xinha` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `data` text collate utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_toolbar_xinha`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_user`
-- 

DROP TABLE IF EXISTS `exponent_user`;
CREATE TABLE IF NOT EXISTS `exponent_user` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(30) collate utf8_unicode_ci NOT NULL,
  `password` varchar(32) collate utf8_unicode_ci NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `is_acting_admin` tinyint(1) NOT NULL,
  `is_locked` tinyint(1) NOT NULL,
  `firstname` varchar(100) collate utf8_unicode_ci NOT NULL,
  `lastname` varchar(100) collate utf8_unicode_ci NOT NULL,
  `email` varchar(100) collate utf8_unicode_ci NOT NULL,
  `recv_html` tinyint(1) NOT NULL,
  `created_on` int(14) NOT NULL,
  `last_login` int(14) NOT NULL,
  `is_ldap` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `exponent_user`
-- 

INSERT IGNORE INTO `exponent_user` (`id`, `username`, `password`, `is_admin`, `is_acting_admin`, `is_locked`, `firstname`, `lastname`, `email`, `recv_html`, `created_on`, `last_login`, `is_ldap`) VALUES 
(1, 'admin', 'd41d8cd98f00b204e9800998ecf8427e', 1, 1, 0, 'System', 'Administrator', '', 0, 1209364120, 1209431741, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_user_address`
-- 

DROP TABLE IF EXISTS `exponent_user_address`;
CREATE TABLE IF NOT EXISTS `exponent_user_address` (
  `uid` int(11) NOT NULL,
  `address1` varchar(150) collate utf8_unicode_ci NOT NULL,
  `address2` varchar(150) collate utf8_unicode_ci NOT NULL,
  `city` varchar(100) collate utf8_unicode_ci NOT NULL,
  `state` varchar(2) collate utf8_unicode_ci NOT NULL,
  `zip` varchar(10) collate utf8_unicode_ci NOT NULL,
  `country` varchar(100) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_user_address`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_user_phone`
-- 

DROP TABLE IF EXISTS `exponent_user_phone`;
CREATE TABLE IF NOT EXISTS `exponent_user_phone` (
  `uid` int(11) NOT NULL,
  `home_phone` varchar(15) collate utf8_unicode_ci NOT NULL,
  `bus_phone` varchar(15) collate utf8_unicode_ci NOT NULL,
  `other_phone` varchar(15) collate utf8_unicode_ci NOT NULL,
  `pref_contact` varchar(20) collate utf8_unicode_ci NOT NULL,
  `contact_time` varchar(20) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_user_phone`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_user_settings`
-- 

DROP TABLE IF EXISTS `exponent_user_settings`;
CREATE TABLE IF NOT EXISTS `exponent_user_settings` (
  `uid` int(11) NOT NULL,
  `SITE_WYSIWYG_EDITOR` varchar(20) collate utf8_unicode_ci NOT NULL,
  `USE_LANG` varchar(6) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_user_settings`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_userpermission`
-- 

DROP TABLE IF EXISTS `exponent_userpermission`;
CREATE TABLE IF NOT EXISTS `exponent_userpermission` (
  `uid` int(11) NOT NULL,
  `permission` varchar(20) collate utf8_unicode_ci NOT NULL,
  `module` varchar(100) collate utf8_unicode_ci NOT NULL,
  `source` varchar(100) collate utf8_unicode_ci NOT NULL,
  `internal` varchar(100) collate utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `exponent_userpermission`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_weblog_comment`
-- 

DROP TABLE IF EXISTS `exponent_weblog_comment`;
CREATE TABLE IF NOT EXISTS `exponent_weblog_comment` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL,
  `name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `email` varchar(150) collate utf8_unicode_ci NOT NULL,
  `body` text collate utf8_unicode_ci NOT NULL,
  `poster` int(11) NOT NULL,
  `posted` int(14) NOT NULL,
  `edited` int(14) NOT NULL,
  `editor` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `exponent_weblog_comment`
-- 

INSERT IGNORE INTO `exponent_weblog_comment` (`id`, `parent_id`, `name`, `email`, `body`, `poster`, `posted`, `edited`, `editor`) VALUES 
(1, 1, 'admin', 'adam@oicgroup.net', 'This is the best blog ever!  Keep up the good work!', 1, 1170803310, 0, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_weblog_post`
-- 

DROP TABLE IF EXISTS `exponent_weblog_post`;
CREATE TABLE IF NOT EXISTS `exponent_weblog_post` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(150) collate utf8_unicode_ci NOT NULL,
  `internal_name` varchar(150) collate utf8_unicode_ci NOT NULL,
  `body` text collate utf8_unicode_ci NOT NULL,
  `is_private` tinyint(1) NOT NULL,
  `poster` int(11) NOT NULL,
  `posted` int(14) NOT NULL,
  `edited` int(14) NOT NULL,
  `editor` int(11) NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `is_draft` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `internal_name` (`internal_name`(10)),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `exponent_weblog_post`
-- 

INSERT IGNORE INTO `exponent_weblog_post` (`id`, `title`, `internal_name`, `body`, `is_private`, `poster`, `posted`, `edited`, `editor`, `location_data`, `is_draft`) VALUES 
(1, 'First Blog Post', '', 'Os hendrerit refoveo duis iriure neque. Ne loquor bis transverbero in\r\npagus vero. Eligo, scisco refero tego ne, fatua feugait eu gilvus\r\nluctus, lobortis. Valde tamen iaceo lobortis wisi patria, olim proprius\r\nconsequat aptent singularis nunc macto augue similis. Duis utrum\r\npraesent in consequat wisi esca, loquor, minim nibh abigo esse\r\nimportunus. Ne lobortis rusticus venio nobis capto diam opto. Iustum\r\nvero acsi, secundum eros, premo in. <br /><br />Aliquip esse nibh illum,\r\nparatus nulla oppeto, huic sino, nobis. Antehabeo vel iriure\r\nullamcorper suscipit ad si quidem reprobo, vereor consequat. Wisi in\r\nletalis obruo feugait indoles facilisi ludus, quibus sagaciter validus.\r\nFacilisis similis iusto os saluto feugiat foras jugis abico imputo,\r\nluptatum, abluo in.', 0, 1, 1100221011, 1100221011, 1, 'O:8:"stdClass":3:{s:3:"mod";s:12:"weblogmodule";s:3:"src";s:20:"@random41940a4020842";s:3:"int";s:0:"";}', 0),
(2, 'These Blogs Are Cool!', '', '<p>Foras ut ne qui ratis, facilisi esse decet dolor vulputate ymo. Suscipere, nonummy duis at, patria eros consequat inhibeo. Qui exputo dignissim scisco esse foras venio lucidus. Dignissim illum luptatum, inhibeo, ad nonummy tamen immitto brevitas incassum, suscipit caecus.</p>\r\n<p>Odio dolore aliquip, veniam loquor augue gemino duis facilisi veniam minim illum jus. Autem, iustum rusticus importunus minim, abigo ullamcorper probo ad eros importunus abbas si imputo populus. Iriure, ea quis dolus torqueo brevitas at, opes, sudo in duis lenis accumsan rusticus. Duis ea iaceo pagus, ratis commodo utinam feugait letalis neque abdo, ratis nostrud. Dignissim opto enim consequat ymo volutpat. Ullamcorper reprobo probo diam feugait ymo sit fatua conventio facilisi pertineo, zelus, pala bene.</p>\r\n<p>Suscipit capio quadrum nulla neo, volutpat transverbero quis, nulla nulla molior nutus autem. Exerci capio natu ingenium quibus neque probo aliquip blandit iriure iriure tristique lenis macto. Ingenium magna verto et haero, commodo pecus inhibeo wisi quidne erat foras.</p>\r\n<p>&nbsp;</p>', 0, 1, 1202623375, 0, 0, 'O:8:"stdClass":3:{s:3:"mod";s:12:"weblogmodule";s:3:"src";s:20:"@random41940a4020842";s:3:"int";s:0:"";}', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_weblogmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_weblogmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_weblogmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `allow_comments` tinyint(1) NOT NULL,
  `comments_notify` varchar(200) collate utf8_unicode_ci NOT NULL,
  `items_per_page` int(8) NOT NULL,
  `enable_rss` tinyint(1) NOT NULL,
  `feed_title` varchar(75) collate utf8_unicode_ci NOT NULL,
  `feed_desc` int(8) NOT NULL,
  `aggregate` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `exponent_weblogmodule_config`
-- 

INSERT IGNORE INTO `exponent_weblogmodule_config` (`id`, `location_data`, `allow_comments`, `comments_notify`, `items_per_page`, `enable_rss`, `feed_title`, `feed_desc`, `aggregate`) VALUES 
(1, 'O:8:"stdClass":3:{s:3:"mod";s:12:"weblogmodule";s:3:"src";s:20:"@random41940a4020842";s:3:"int";s:0:"";}', 1, '', 10, 1, 'Example Exponent CMS Blog', 0, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_wizard`
-- 

DROP TABLE IF EXISTS `exponent_wizard`;
CREATE TABLE IF NOT EXISTS `exponent_wizard` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_wizard`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_wizard_address`
-- 

DROP TABLE IF EXISTS `exponent_wizard_address`;
CREATE TABLE IF NOT EXISTS `exponent_wizard_address` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(100) collate utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `wizard_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_wizard_address`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_wizard_control`
-- 

DROP TABLE IF EXISTS `exponent_wizard_control`;
CREATE TABLE IF NOT EXISTS `exponent_wizard_control` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `caption` varchar(150) collate utf8_unicode_ci NOT NULL,
  `form_id` int(11) NOT NULL,
  `data` text collate utf8_unicode_ci NOT NULL,
  `rank` int(8) NOT NULL,
  `is_readonly` tinyint(1) NOT NULL,
  `is_static` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_wizard_control`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_wizard_form`
-- 

DROP TABLE IF EXISTS `exponent_wizard_form`;
CREATE TABLE IF NOT EXISTS `exponent_wizard_form` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `table_name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `wizard_page_id` int(11) NOT NULL,
  `wizard_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_wizard_form`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_wizard_pages`
-- 

DROP TABLE IF EXISTS `exponent_wizard_pages`;
CREATE TABLE IF NOT EXISTS `exponent_wizard_pages` (
  `id` int(11) NOT NULL auto_increment,
  `wizard_id` int(11) NOT NULL,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `rank` int(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_wizard_pages`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_wizard_report`
-- 

DROP TABLE IF EXISTS `exponent_wizard_report`;
CREATE TABLE IF NOT EXISTS `exponent_wizard_report` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `text` text collate utf8_unicode_ci NOT NULL,
  `wizard_id` int(11) NOT NULL,
  `column_names` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_wizard_report`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_wizardmodule_config`
-- 

DROP TABLE IF EXISTS `exponent_wizardmodule_config`;
CREATE TABLE IF NOT EXISTS `exponent_wizardmodule_config` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(200) collate utf8_unicode_ci NOT NULL,
  `wizard_id` int(8) NOT NULL,
  `is_email` tinyint(1) NOT NULL,
  `is_saved` tinyint(1) NOT NULL,
  `response` text collate utf8_unicode_ci NOT NULL,
  `submitbtn` varchar(100) collate utf8_unicode_ci NOT NULL,
  `resetbtn` varchar(100) collate utf8_unicode_ci NOT NULL,
  `subject` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_wizardmodule_config`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_workflowaction`
-- 

DROP TABLE IF EXISTS `exponent_workflowaction`;
CREATE TABLE IF NOT EXISTS `exponent_workflowaction` (
  `id` int(11) NOT NULL auto_increment,
  `policy_id` int(11) NOT NULL,
  `type` int(8) NOT NULL,
  `rank` int(8) NOT NULL,
  `method` varchar(100) collate utf8_unicode_ci NOT NULL,
  `parameters` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_workflowaction`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `exponent_youtube`
-- 

DROP TABLE IF EXISTS `exponent_youtube`;
CREATE TABLE IF NOT EXISTS `exponent_youtube` (
  `id` int(11) NOT NULL auto_increment,
  `location_data` varchar(250) collate utf8_unicode_ci NOT NULL,
  `height` varchar(4) collate utf8_unicode_ci NOT NULL,
  `width` varchar(4) collate utf8_unicode_ci NOT NULL,
  `url` varchar(150) collate utf8_unicode_ci NOT NULL,
  `name` varchar(150) collate utf8_unicode_ci NOT NULL,
  `description` mediumtext collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `location_data` (`location_data`(10))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `exponent_youtube`
-- 

